'use strict';
// Structural/accessibility DOM checks only. LinkeDOM does not render pixels or
// measure layout; these checks are not browser/mobile visual verification.
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { parseHTML } = process.env.KIKISHIELD_DOM_MODULES
    ? require(path.join(process.env.KIKISHIELD_DOM_MODULES, 'linkedom')) : require('linkedom');
const { harness } = require('./harness.cjs');

function fixture() {
    const { window } = parseHTML('<!doctype html><html><body><main>Offline UI fixture</main></body></html>');
    Object.defineProperty(window.HTMLSelectElement.prototype, 'value', {
        configurable: true,
        get() { return this.querySelector('option[selected]')?.value ?? this.querySelector('option')?.value ?? ''; },
        set(value) { for (const option of this.querySelectorAll('option')) option.toggleAttribute('selected', option.value === String(value)); }
    });
    window.HTMLElement.prototype.getBoundingClientRect = function () {
        const width = this.id === 'badge' ? 46 : 366, height = this.id === 'badge' ? 46 : 600;
        return { left: 12, top: 12, right: 12 + width, bottom: 12 + height, width, height, x: 12, y: 12 };
    };
    Object.defineProperty(window.HTMLElement.prototype, 'offsetWidth', { configurable: true, get() { return this.id === 'badge' ? 46 : 366; } });
    Object.defineProperty(window.HTMLElement.prototype, 'offsetHeight', { configurable: true, get() { return this.id === 'badge' ? 46 : 600; } });
    const f = harness(undefined, new Map(), false);
    Object.assign(f.W, { document: window.document, innerWidth: 390, innerHeight: 844, addEventListener() {}, Blob,
        URL: { createObjectURL() { return 'blob:offline'; }, revokeObjectURL() {} } });
    f.shield.tick();
    f.shadow = window.document.getElementById('kikishield-root').shadowRoot;
    f.el = id => f.shadow.getElementById(id);
    f.el('badge').onclick({ detail: 0 });
    f.key = (id, key) => {
        const event = new window.Event('keydown', { bubbles: true, cancelable: true });
        Object.defineProperty(event, 'key', { value: key });
        f.el(id).dispatchEvent(event);
        assert.equal(event.defaultPrevented, true, key + ' is handled by KikiShield');
    };
    return f;
}

function nameOf(node, shadow) {
    if (node.getAttribute('aria-label')?.trim()) return node.getAttribute('aria-label').trim();
    if (node.getAttribute('aria-labelledby')) return node.getAttribute('aria-labelledby').split(/\s+/)
        .map(id => shadow.getElementById(id)?.textContent || '').join(' ').trim();
    if (node.localName === 'button' || node.localName === 'summary') return node.textContent.trim();
    return (node.closest('label')?.textContent || (node.id && shadow.querySelector('label[for="' + node.id + '"]')?.textContent) || '').trim();
}

test('every settings control keeps an accessible name and valid help references', () => {
    const f = fixture();
    for (const node of f.shadow.querySelectorAll('button,input,select,summary')) {
        assert(nameOf(node, f.shadow), 'missing accessible name: ' + (node.id || node.outerHTML.slice(0, 100)));
        for (const id of (node.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean))
            assert(f.el(id), 'missing description ' + id);
    }
    assert.equal(f.W.document.getElementById('kikishield-root').lang, 'en');
    assert.match(f.shadow.querySelector('footer').textContent, /Made By Kiki #72385/);
});

test('all setting rows and navigation use the same icon structure, with decorative SVGs', () => {
    const f = fixture();
    const settings = [...f.shadow.querySelectorAll('.setting')];
    assert.equal(settings.length, 9, 'all nine protection and automation switches remain present');
    for (const row of settings) {
        assert.equal(row.querySelectorAll('.row-icon').length, 1, 'one consistent icon slot per setting');
        assert.equal(row.querySelectorAll('.copy').length, 1, 'one aligned text column per setting');
        assert.equal(row.querySelectorAll('input.switch').length, 1, 'one shared switch control per setting');
        assert(row.querySelector('.row-icon svg'), 'each setting has a local vector icon');
    }
    for (const tab of f.shadow.querySelectorAll('[role="tab"]'))
        assert(tab.querySelector('.tab-glyph svg'), 'each tab has an icon independent of its label');
    for (const summary of f.shadow.querySelectorAll('.fold > summary'))
        assert(summary.querySelector('svg'), 'each collapsible section has an icon');
    for (const svg of f.shadow.querySelectorAll('svg')) {
        assert.equal(svg.getAttribute('aria-hidden'), 'true', 'decorative icons do not duplicate accessible names');
        assert(svg.children.length, 'an icon has drawable geometry');
        assert(!svg.textContent.includes('undefined'), 'an icon name resolves to valid geometry');
        assert.equal(svg.querySelector('script,use,image'), null, 'icons are self-contained vector paths');
    }
});

test('tab clicks and keyboard navigation keep exactly one selected, labelled panel', () => {
    const f = fixture();
    function selected(name) {
        const tabs = [...f.shadow.querySelectorAll('[role="tab"]')];
        assert.equal(tabs.length, 3);
        assert.equal(tabs.filter(tab => tab.getAttribute('aria-selected') === 'true').length, 1);
        assert.equal(f.el('tab-' + name).getAttribute('aria-selected'), 'true');
        for (const tab of tabs) {
            const panel = f.el(tab.getAttribute('aria-controls'));
            assert(panel, 'tab targets an existing panel');
            assert.equal(panel.getAttribute('aria-labelledby'), tab.id);
            assert.equal(panel.hidden, tab.getAttribute('aria-selected') !== 'true');
            // LinkeDOM's tabIndex getter maps literal 0 to -1; inspect the
            // reflected attribute written by the real navigation routine.
            assert.equal(tab.getAttribute('tabindex'), tab.getAttribute('aria-selected') === 'true' ? '0' : '-1');
        }
    }
    // Click first to exercise the shared selection routine as well as keyboard.
    f.el('tab-protection').onclick(); selected('protection');
    f.key('tab-protection', 'ArrowRight'); selected('automation');
    f.key('tab-automation', 'End'); selected('activity');
    f.key('tab-activity', 'ArrowRight'); selected('protection');
    f.key('tab-protection', 'ArrowLeft'); selected('activity');
    f.key('tab-activity', 'Home'); selected('protection');
    f.el('tab-automation').onclick(); selected('automation');
    f.key('tab-automation', 'Escape');
    assert.equal(f.el('panel').hidden, true);
    assert.equal(f.el('badge').getAttribute('aria-expanded'), 'false');
});

test('tab changes preserve the panel size and constrain it to small viewports', () => {
    const f = fixture();
    for (const [width, height, panelWidth, panelHeight] of [
        [1100, 760, 380, 600], [390, 844, 366, 600], [320, 568, 296, 544], [844, 390, 380, 366]
    ]) {
        f.W.innerWidth = width; f.W.innerHeight = height;
        for (const tab of ['protection', 'automation', 'activity']) {
            f.el('tab-' + tab).onclick();
            // These are explicit sizing instructions, not measured layout.
            assert.equal(f.el('panel').style.width, panelWidth + 'px', tab + ' width at ' + width + '×' + height);
            assert.equal(f.el('panel').style.height, panelHeight + 'px', tab + ' height at ' + width + '×' + height);
        }
    }
});

test('redesigned controls retain every protection and automation setting', () => {
    const f = fixture();
    const switches = [
        ['block-bcc', 'blockBCC'], ['block-lscg', 'blockLSCG'], ['restore', 'restoreAppearance'],
        ['hidden', 'blockOtherHidden'], ['graphics', 'guardGraphics'], ['auto-violation', 'autoOnViolation'],
        ['auto-bcc', 'autoOnBCC'], ['auto-lscg', 'autoOnLSCG'], ['auto-trusted', 'autoProtectTrusted']
    ];
    for (const [id, key] of switches) {
        const control = f.el(id); assert(control, id + ' retained');
        for (const value of [false, true]) {
            control.checked = value; control.onchange();
            assert.equal(f.shield.status().options[key], value, id + ' still updates ' + key);
        }
    }
    const modes = [...f.shadow.querySelectorAll('input[name="interaction"]')];
    assert.deepEqual(modes.map(input => input.value), ['native', 'whitelist', 'none']);
    for (const input of modes) {
        input.checked = true; input.onchange();
        assert.equal(f.shield.status().options.interactionMode, input.value);
    }
    for (const [id, values, key] of [
        ['auto-action', ['off', 'blacklist', 'ghost'], 'autoAction'],
        ['auto-threshold', ['1', '2', '3'], 'autoThreshold']
    ]) {
        assert.deepEqual([...f.el(id).querySelectorAll('option')].map(option => option.value), values);
        for (const value of values) {
            f.el(id).value = value; f.el(id).onchange();
            assert.equal(String(f.shield.status().options[key]), value);
        }
    }
    assert.deepEqual([...f.el('severity-filter').querySelectorAll('option')].map(option => option.value),
        ['all', 'serious', 'caution', 'background', 'system']);
});

test('secondary explanations start collapsed and primary actions stay outside disclosures', () => {
    const f = fixture();
    for (const id of ['advanced', 'about', 'auto-exceptions-section', 'auto-about', 'activity-about']) {
        const fold = f.el(id); assert(fold, id + ' disclosure retained');
        assert.equal(fold.localName, 'details'); assert.equal(!!fold.open, false);
        assert(fold.querySelector('summary'), id + ' has a discoverable title');
    }
    for (const id of ['panic-button', 'close', 'block-bcc', 'block-lscg', 'auto-action', 'severity-filter', 'clear', 'export']) {
        assert.equal(f.el(id).closest('details'), null, id + ' does not require an extra disclosure tap');
    }
    assert.equal(f.el('panic-button').getAttribute('aria-describedby'), 'panic-explanation');
    assert(f.el('panic-explanation').textContent.includes('You stay connected'));
    for (const id of ['clear', 'export']) {
        assert(f.el(id).getAttribute('aria-label')?.trim(), id + ' icon action has an explicit name');
        assert(f.el(id).getAttribute('title')?.trim(), id + ' icon action has a tooltip');
    }
});
