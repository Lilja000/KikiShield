'use strict';
// Offline regression fixture. No real BC accounts or network operations.
// Run in an approved local browser test environment; this file is not part of the userscript.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { chromium } = process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES
    ? require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES + '/playwright') : require('playwright');
const source = fs.readFileSync(path.resolve(__dirname, '../KikiShield.user.js'), 'utf8');
const fixture = `<!doctype html><html lang="en"><meta charset="utf-8"><title>KikiShield Activity test</title>
<body style="background:#232327;color:#fff;font:15px system-ui"><p>Offline activity fixture</p><script>
class TestSocket {
  constructor(){this.connected=false;this.receiveBuffer=[];this.handlers=new Map();this.any=[];}
  on(name,fn){const a=this.handlers.get(name)||[];a.push(fn);this.handlers.set(name,a);return this;}
  onAny(fn){this.any.push(fn);return this;}
  emitEvent(args){for(const f of this.any)f(...args);for(const f of this.handlers.get(args[0])||[])f(...args.slice(1));}
  onevent(packet){const args=packet.data||[];if(this.connected)this.emitEvent(args);else this.receiveBuffer.push(args);}
  emitBuffered(){this.receiveBuffer.forEach(args=>this.emitEvent(args));this.receiveBuffer=[];}
}
var ServerSocket=null;
var Player={MemberNumber:100,CharacterID:'offline',AllowedInteractions:3,WhiteList:[200],BlackList:[],GhostList:[],FriendList:[],Ownership:null,Lovership:[],Appearance:[{Name:'Accepted',Group:'Test'}],ActivePose:[]};
var ChatRoomCharacter=[{MemberNumber:200},{MemberNumber:300},{MemberNumber:301},{MemberNumber:302}];
var ChatRoomData={ID:'offline',Name:'Offline',Character:[]};var ChatRoomAllowCharacterUpdate=true;
var ServerAppearanceBundle=a=>structuredClone(a);var ChatRoomCharacterUpdate=()=>{};
var listWrites=[];var ServerAccountUpdate={QueueData:data=>listWrites.push(structuredClone(data))};
var ServerSend=(type,data)=>listWrites.push({type,data:structuredClone(data)});
var ChatRoomListUpdate=(list,add,id)=>{if(add&&!list.includes(id))list.push(id);else if(!add){const index=list.indexOf(id);if(index>=0)list.splice(index,1);}};
ServerSocket=new TestSocket();ServerSocket.connected=true;
window.injectEvent=(event,data)=>ServerSocket.onevent({data:[event,data]});
</script></body></html>`;
(async () => {
    const browser = await chromium.launch({headless:true,...(process.env.KIKISHIELD_CHROMIUM?{executablePath:process.env.KIKISHIELD_CHROMIUM}:{}),args:['--no-sandbox']});
    const results = [];
    try {
        const context = await browser.newContext({viewport:{width:390,height:844}});
        await context.addInitScript({content:source});
        await context.route('**/*', route => route.request().url() === 'https://kikishield.test/'
            ? route.fulfill({contentType:'text/html',body:fixture}) : route.abort());
        const page=await context.newPage(), errors=[];page.on('pageerror',e=>errors.push(e.message));
        await page.goto('https://kikishield.test/');
        await page.waitForFunction(()=>window.KikiShield?.status().state==='active');
        const host=page.locator('#kikishield-root'), el=id=>host.locator('#'+id);
        await el('badge').click();
        assert.equal(await el('view-automation').isVisible(),false);
        await el('tab-automation').click();
        assert.equal(await el('auto-exceptions-section').getAttribute('open'),null);
        await el('auto-exceptions-section').locator('summary').click();
        assert.equal(await el('auto-action').inputValue(),'off');
        assert.equal(await el('auto-bcc').isChecked(),false);
        assert.equal(await el('auto-lscg').isChecked(),false);
        assert.equal(await el('auto-trusted').isChecked(),true);
        await el('auto-exceptions').fill('200, 301');await el('auto-exceptions-save').click();
        assert.deepEqual(await page.evaluate(()=>KikiShield.status().options.autoExceptions),[200,301]);
        for(const invalid of ['200, nope, 301','200,','+200','200;301','9007199254740992','1,,2']) {
            await el('auto-exceptions').fill(invalid);await el('auto-exceptions-save').click();
            assert.equal(await el('auto-exceptions').getAttribute('aria-invalid'),'true');
            assert.deepEqual(await page.evaluate(()=>KikiShield.status().options.autoExceptions),[200,301]);
            assert.equal(await el('auto-exceptions').inputValue(),invalid);
        }
        await el('auto-exceptions').fill('301, 301, 200');await el('auto-exceptions-save').click();
        assert.equal(await el('auto-exceptions').inputValue(),'301, 200');
        await el('auto-exceptions').fill('');await el('auto-exceptions-save').click();
        assert.deepEqual(await page.evaluate(()=>KikiShield.status().options.autoExceptions),[]);
        results.push('strict exceptions preserve the previous list on invalid drafts; deduplicate valid input; allow explicit clear');
        await el('auto-threshold').selectOption('3');await el('auto-bcc').check();
        assert.equal(await page.evaluate(()=>KikiShield.status().options.autoThreshold),3);
        assert.equal(await page.evaluate(()=>KikiShield.status().options.autoOnBCC),true);
        // Automation remains off during payload inspection.
        await el('auto-exceptions-section').locator('summary').click();await el('tab-activity').click();
        await page.evaluate(()=>injectEvent('ChatRoomMessage',{Sender:300,Type:'Hidden',Content:'BCC',Dictionary:{msg:'animaFurtaCommand',data:{name:'changeAppearance',target:100,payload:'<img src=x onerror="window.fixtureXss=true">'}}}));
        await page.waitForFunction(()=>document.getElementById('kikishield-root').shadowRoot.querySelectorAll('#events li').length>0);
        const first=el('events').locator('li').first();
        const id=await first.getAttribute('data-event-id');
        await first.locator('summary').click();
        assert.match(await first.locator('pre').textContent(),/<img src=x onerror=/);
        assert.equal(await first.locator('.event-detail img').count(),0);
        assert.equal(await page.evaluate(()=>!!window.fixtureXss),false);
        assert.equal(await first.locator('details').getAttribute('open'),'');
        results.push('hostile command text is inspectable and inert');
        await page.evaluate(()=>injectEvent('ChatRoomSyncItem',{Source:301,Item:{Target:100,Group:'Test',Name:'Blocked'}}));
        await page.waitForFunction(()=>document.getElementById('kikishield-root').shadowRoot.querySelectorAll('#events li').length>1);
        assert.equal(await el('events').locator('li[data-event-id="'+id+'"]').locator('details').getAttribute('open'),'');
        results.push('expanded details survive additional activity');
        for(const severity of ['serious','caution','background','system','all']) {
            await el('severity-filter').selectOption(severity);
            const counts=await page.evaluate(severity=>{const logs=KikiShield.getLog();return {total:logs.length,shown:logs.filter(x=>severity==='all'||x.severity===severity).length};},severity);
            assert.equal(await el('events').locator('li').count(),counts.shown);
            assert.equal(await el('event-count').textContent(),counts.shown+' of '+counts.total);
            assert.equal(await el('empty').isVisible(),counts.shown===0);
            if(!counts.shown)assert.equal(await el('empty-title').textContent(),'No matching events');
        }
        assert.equal(await el('events').locator('li[data-event-id="'+id+'"]').locator('details').getAttribute('open'),'');
        results.push('severity filters, empty states, and counts are correct; details reopen after filtering');
        const [download]=await Promise.all([page.waitForEvent('download'),el('export').click()]);
        const exported=JSON.parse(fs.readFileSync(await download.path(),'utf8'));
        assert(exported.events.some(x=>x.detail?.includes('changeAppearance')));
        await el('clear').click();
        assert.equal(await el('events').locator('li').count(),0);
        assert.equal(await el('empty-title').textContent(),'No events yet');
        assert.equal(await el('export').isDisabled(),true);
        results.push('export retains captured commands; Clear empties activity');
        await el('tab-automation').click();await el('auto-exceptions-section').locator('summary').click();
        for(const viewport of [{width:320,height:568},{width:844,height:390}]) {
            await page.setViewportSize(viewport);
            await page.waitForFunction(()=>{const s=document.getElementById('kikishield-root').shadowRoot,p=s.getElementById('panel'),r=p.getBoundingClientRect();return r.left>=0&&r.right<=innerWidth&&r.bottom<=innerHeight;});
            assert.equal(await el('view-automation').evaluate(node=>node.scrollWidth<=node.clientWidth),true);
        }
        assert.deepEqual(errors,[]);results.push('small portrait and landscape layouts contain controls without horizontal overflow');
        process.stdout.write(JSON.stringify({passed:results.length,checks:results},null,2)+'\n');
    } finally { await browser.close(); }
})().catch(error=>{console.error(error);process.exitCode=1;});
