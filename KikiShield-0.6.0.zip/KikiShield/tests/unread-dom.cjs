'use strict';
// DOM simulation only; never starts a browser or contacts a game account/server.
// Optional dependency: KIKISHIELD_DOM_MODULES=/path/to/node_modules node --test tests/unread-dom.cjs
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { parseHTML } = process.env.KIKISHIELD_DOM_MODULES
    ? require(path.join(process.env.KIKISHIELD_DOM_MODULES, 'linkedom')) : require('linkedom');
const createShield = require('../KikiShield.user.js');
const { TestSocket } = require('./harness.cjs');

function fixture() {
    const { window } = parseHTML('<!doctype html><html><body><main>Offline unread fixture</main></body></html>');
    Object.defineProperty(window.HTMLSelectElement.prototype, 'value', {
        configurable: true,
        get() { return this.querySelector('option[selected]')?.value ?? this.querySelector('option')?.value ?? ''; },
        set(value) { for (const option of this.querySelectorAll('option')) option.toggleAttribute('selected', option.value === String(value)); }
    });
    window.HTMLElement.prototype.getBoundingClientRect = function () {
        const width = this.id === 'badge' ? 46 : 366, height = this.id === 'badge' ? 46 : 560;
        return { left: 12, top: 12, right: 12 + width, bottom: 12 + height, width, height, x: 12, y: 12 };
    };
    Object.defineProperty(window.HTMLElement.prototype, 'offsetWidth', { configurable: true, get() { return this.id === 'badge' ? 46 : 366; } });
    Object.defineProperty(window.HTMLElement.prototype, 'offsetHeight', { configurable: true, get() { return this.id === 'badge' ? 46 : 560; } });
    let visibility = 'visible';
    Object.defineProperty(window.document, 'visibilityState', { configurable: true, get: () => visibility });
    const callbacks = new Map(), saved = new Map(); let next = 1;
    const W = {
        document: window.document, innerWidth: 390, innerHeight: 844, addEventListener() {},
        URL: { createObjectURL() { return 'blob:local'; }, revokeObjectURL() {} }, Blob,
        Player: { MemberNumber: 100, CharacterID: 'offline', AllowedInteractions: 3, WhiteList: [200], BlackList: [], GhostList: [], FriendList: [],
            Ownership: null, Lovership: [], Appearance: [{ Name: 'Accepted', Group: 'Test' }], ActivePose: [] },
        ChatRoomCharacter: [{ MemberNumber: 200 }, { MemberNumber: 300 }], ChatRoomData: { ID: 'offline', Name: 'Offline', Character: [] },
        ChatRoomAllowCharacterUpdate: true, ServerSocket: null, ServerAppearanceBundle: a => structuredClone(a), ChatRoomCharacterUpdate() {},
        localStorage: { getItem: k => saved.get(k), setItem: (k, v) => saved.set(k, v) },
        setInterval: () => 999, clearInterval() {}, setTimeout: fn => { callbacks.set(next, fn); return next++; }, clearTimeout: id => callbacks.delete(id)
    };
    const shield = createShield(W).start(); W.ServerSocket = new TestSocket(); W.ServerSocket.connected = true; shield.tick();
    const shadow = W.document.getElementById('kikishield-root').shadowRoot, el = id => shadow.getElementById(id);
    const f = {
        W, shield, shadow, el,
        receive() { W.ServerSocket.onevent({ data: ['ChatRoomMessage', { Sender: 300, Type: 'Hidden', Content: 'BCC', Dictionary: { msg: 'syncStorage', data: { storage: { version: '2.2.3' } } } }] }); },
        flush() {
            for (let iteration = 0; callbacks.size && iteration < 10; iteration++) {
                const pending = [...callbacks.values()]; callbacks.clear(); for (const fn of pending) fn();
            }
            assert.equal(callbacks.size, 0, 'coalesced rendering settles without a timer loop');
        },
        unread() { return shield.status().activity.unread; },
        open() { if (el('panel').hidden) el('badge').onclick({ detail: 0 }); },
        close() { el('close').onclick(); },
        tab(name) { el('tab-' + name).onclick(); },
        setVisibility(value) { visibility = value; W.document.dispatchEvent(new window.Event('visibilitychange')); }
    };
    f.flush(); return f;
}
function assertBadges(f, count) {
    for (const id of ['badge-unread', 'activity-count']) {
        const badge = f.el(id); assert(badge, id + ' exists');
        assert.equal(badge.hidden, count === 0, id + ' visibility');
        if (count) assert.equal(badge.textContent, count > 99 ? '99+' : String(count), id + ' count');
    }
}

test('closed-menu unread counts each blocked event, including deduplicated Activity rows', () => {
    const f = fixture(); assert.equal(f.unread(), 0); assertBadges(f, 0);
    f.receive(); assert.equal(f.unread(), 1, 'counter updates synchronously with ingress');
    f.receive(); assert.equal(f.unread(), 2);
    const log = f.shield.getLog(); assert.equal(log.length, 1); assert.equal(log[0].count, 2);
    f.flush(); assertBadges(f, 2);
});

test('Protection and Automation keep notifications unread; entering Activity marks the whole journal read', () => {
    const f = fixture(); f.receive(); f.flush(); f.open();
    assert.equal(f.el('tab-protection').getAttribute('aria-selected'), 'true');
    assert.equal(f.unread(), 1); assertBadges(f, 1);
    f.tab('automation'); f.flush(); assert.equal(f.unread(), 1); assertBadges(f, 1);
    f.tab('activity'); f.flush(); assert.equal(f.unread(), 0); assertBadges(f, 0);
    assert.equal(f.shield.getLog().length, 1, 'reading never deletes Activity history');
});

test('an Activity tab in a hidden browser does not consume unread until visibility returns', () => {
    const f = fixture(); f.open(); f.tab('activity'); f.setVisibility('hidden');
    f.receive(); f.flush(); assert.equal(f.unread(), 1); assertBadges(f, 1);
    f.shield.tick(); assert.equal(f.unread(), 1, 'background health checks do not mark hidden content read');
    f.setVisibility('visible'); f.flush(); assert.equal(f.unread(), 0); assertBadges(f, 0);
    f.close(); f.setVisibility('hidden'); f.receive(); f.flush(); f.setVisibility('visible'); f.flush();
    assert.equal(f.unread(), 1, 'visibility alone is insufficient when the menu is closed');
});

test('closing a selected Activity tab resumes unread counting; reopening it clears the counter', () => {
    const f = fixture(); f.open(); f.tab('activity');
    f.receive(); f.flush(); assert.equal(f.unread(), 0);
    f.close(); f.receive(); assert.equal(f.unread(), 1); f.flush(); assertBadges(f, 1);
    f.open(); f.flush(); assert.equal(f.unread(), 0); assertBadges(f, 0);
    assert.equal(f.el('tab-activity').getAttribute('aria-selected'), 'true');
    assert.equal(f.shield.getLog()[0].count, 2);
});

test('severity filtering, settings edits, and idle rerenders do not create unread events', () => {
    const f = fixture(); f.open(); f.tab('activity');
    f.el('severity-filter').value = 'serious'; f.el('severity-filter').onchange();
    f.receive(); f.flush(); assert.equal(f.el('events').children.length, 0, 'background event is filtered out of the visible list');
    assert.equal(f.unread(), 0, 'the entire Activity journal is read even with a severity filter');
    f.tab('protection'); f.receive(); f.flush(); assert.equal(f.unread(), 1);
    f.shield.configure({ guardGraphics: false }); f.shield.tick(); f.shield.tick(); f.flush();
    assert.equal(f.unread(), 1); assertBadges(f, 1);
});

test('launcher and tab badges cap their display at 99+ while preserving the actual unread count', () => {
    const f = fixture(); for (let n = 0; n < 150; n++) f.receive();
    assert.equal(f.unread(), 150); assert.equal(f.shield.getLog().length, 1); assert.equal(f.shield.getLog()[0].count, 150);
    f.flush(); assertBadges(f, 150);
    f.open(); f.tab('activity'); f.flush(); assert.equal(f.unread(), 0); assertBadges(f, 0);
});

test('Clear and account changes reset unread without leaking another account’s notifications', () => {
    const f = fixture(); f.receive(); f.flush(); assert.equal(f.unread(), 1);
    f.shield.clearLog(); f.flush(); assert.equal(f.unread(), 0); assertBadges(f, 0);
    f.receive(); assert.equal(f.unread(), 1);
    f.W.Player = { ...f.W.Player, MemberNumber: 400, BlackList: [], GhostList: [], WhiteList: [], FriendList: [], Lovership: [] };
    f.shield.tick(); f.flush(); assert.equal(f.unread(), 0); assertBadges(f, 0); assert.deepEqual(f.shield.getLog(), []);
});

test('Panic does not count its hidden Activity tab as viewed and resuming Activity clears notifications', () => {
    const f = fixture(); f.open(); f.tab('activity');
    assert.doesNotThrow(() => f.shield.setPanic(true)); f.receive(); f.flush();
    assert.equal(f.unread(), 1); assert.equal(f.shield.status().panic.active, true); assert.equal(f.el('panel').hidden, true);
    f.shield.tick(); f.flush(); assert.equal(f.unread(), 1);
    assert.doesNotThrow(() => f.shield.setPanic(false)); f.flush();
    assert.equal(f.shield.status().panic.active, false); assert.equal(f.el('panel').hidden, false); assert.equal(f.unread(), 0); assertBadges(f, 0);
});

test('closing Activity before the deferred event paint preserves its unread notification', () => {
    const f = fixture(); f.open(); f.tab('activity');
    assert.equal(f.el('events').children.length, 0);
    f.receive();
    assert.equal(f.unread(), 1, 'receiving is not an acknowledgement before the event is rendered');
    assert.equal(f.el('events').children.length, 0, 'the coalesced paint has not run yet');
    f.close(); f.flush();
    assert.equal(f.unread(), 1); assertBadges(f, 1);
    f.open(); f.flush();
    assert.equal(f.el('events').children.length, 1); assert.equal(f.unread(), 0); assertBadges(f, 0);
});
