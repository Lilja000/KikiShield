'use strict';
// Actual production R132 validators, invoked behind the ingress gate with inert assets.
const test = require('node:test'), assert = require('node:assert/strict');
const fs = require('node:fs'), vm = require('node:vm'), path = require('node:path');
const { harness, item } = require('./harness.cjs');
const root = process.env.KIKISHIELD_UPSTREAM || path.resolve(__dirname, '../..');
const source = fs.readFileSync(path.join(root, 'shield-hardening-audit/R132-Scripts_Validation.js'), 'utf8');
function fixture() {
    const h = harness(), p = h.W.Player;
    Object.assign(p, { FriendList: [], OnlineSharedSettings: { AllowFullWardrobeAccess: false, BlockBodyCosplay: false },
        IsPlayer: () => true, IsOwnedByMemberNumber: n => p.Ownership?.MemberNumber === n,
        IsInFamilyOfMemberNumber: () => false, IsLoverOfMemberNumber: n => p.Lovership.some(x => x.MemberNumber === n),
        HasOnWhitelist: n => p.WhiteList.includes(n) });
    const env = { Player: p, console: { error() {} },
        ScriptPermissionLevel: { SELF: 1, OWNER: 2, LOVERS: 4, FRIENDS: 8, WHITELIST: 16, PUBLIC: 32 },
        CharacterGetLoversNumbers: c => c.Lovership.map(x => x.MemberNumber), LogQuery: () => false,
        InventoryIsPermissionBlocked: (_c, name) => name === 'Blocked', InventoryIsPermissionLimited: (_c, name) => name === 'Limited',
        OnlineGameAllowBlockItems: () => true, InventoryGetItemProperty: (i, name) => i.Asset[name],
        InventoryGetLock: i => i.Lock || null, InventoryOwnerOnlyItem: i => !!i.Asset.OwnerOnly,
        InventoryLoverOnlyItem: i => !!i.Asset.LoverOnly, InventoryFamilyOnlyItem: i => !!i.Asset.FamilyOnly };
    vm.createContext(env); vm.runInContext(source, env);
    const asset = (name = 'Allowed', changes = {}) => ({ Asset: { Name: name, Enable: true, Group: { Name: 'Test', Category: 'Item', AllowNone: true }, ...changes } });
    const ingress = (id, fn) => {
        const event = h.shield.filter(['ChatRoomSyncItem', item(id)]);
        return event && fn(env.ValidationCreateDiffParams(p, event[1].Source));
    };
    return { ...h, env, asset, ingress };
}

test('R132: allowed clothing and restraints stay allowed; blocked/limited items keep native restrictions', () => {
    const h = fixture(), add = (id, asset) => h.ingress(id, params => h.env.ValidationCanAddItem(asset, params));
    assert.equal(add(200, h.asset()), true);
    assert.equal(add(200, h.asset('Shirt', { Group: { Name: 'Cloth', Category: 'Appearance', Clothing: true } })), true);
    assert.equal(add(300, h.asset()), null);
    assert.equal(add(200, h.asset('Blocked')), false);
    assert.equal(add(200, h.asset('Limited')), true);
    h.W.Player.AllowedInteractions = 0; assert.equal(add(300, h.asset('Limited')), false);
    h.W.Player.Ownership = { MemberNumber: 300 }; assert.equal(add(300, h.asset('Limited')), true);
    assert.equal(add(300, h.asset('Blocked')), false);
});

test('R132: body wardrobe and cosplay protection survives authorized access', () => {
    const h = fixture(), params = h.env.ValidationCreateDiffParams(h.W.Player, 200);
    const body = h.asset('Body', { Group: { Name: 'Body', Category: 'Appearance', Clothing: false } });
    assert.equal(h.env.ValidationCanAddItem(body, params), false);
    h.W.Player.OnlineSharedSettings.AllowFullWardrobeAccess = true;
    assert.equal(h.env.ValidationCanAddItem(body, params), true);
    h.W.Player.OnlineSharedSettings.BlockBodyCosplay = true;
    assert.equal(h.env.ValidationCanAddItem(h.asset('Cosplay', { BodyCosplay: true }), params), false);
});

test('R132: owner and lover lock removal checks survive the shield', () => {
    const h = fixture(); const ownerLock = h.asset(); ownerLock.Lock = { Asset: { OwnerOnly: true } };
    const loverLock = h.asset(); loverLock.Lock = { Asset: { LoverOnly: true } };
    const remove = (id, asset) => h.ingress(id, params => h.env.ValidationCanRemoveItem(asset, params, false));
    assert.equal(remove(200, ownerLock), false); assert.equal(remove(200, loverLock), false);
    h.W.Player.Lovership = [{ MemberNumber: 200 }]; assert.equal(remove(200, loverLock), true); assert.equal(remove(200, ownerLock), false);
    h.W.Player.Ownership = { MemberNumber: 200 }; assert.equal(remove(200, ownerLock), true);
    h.W.Player.GhostList = [200]; assert.equal(remove(200, ownerLock), null);
});

test('R132: script-property permissions distinguish own friendlist and whitelist', () => {
    const h = fixture(); h.W.Player.AllowedInteractions = 0; h.W.Player.FriendList = [300];
    const friend = h.ingress(300, x => x), white = h.ingress(200, x => x);
    assert(friend.permissions.includes(h.env.ScriptPermissionLevel.FRIENDS));
    assert(!friend.permissions.includes(h.env.ScriptPermissionLevel.WHITELIST));
    assert(white.permissions.includes(h.env.ScriptPermissionLevel.WHITELIST));
    assert(!white.permissions.includes(h.env.ScriptPermissionLevel.FRIENDS));
    h.W.Player.AllowedInteractions = 5; assert.equal(h.ingress(300, x => x), null);
});
