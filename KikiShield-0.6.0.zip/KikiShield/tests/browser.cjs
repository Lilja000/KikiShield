'use strict';
// Local fixture only. All remote HTTP requests are aborted. No real account/server.
const fs = require('node:fs');
const path = require('node:path');
const cp = require('node:child_process');
const assert = require('node:assert/strict');
const { chromium } = process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES
    ? require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES + '/playwright') : require('playwright');
const root = process.env.KIKISHIELD_UPSTREAM || path.resolve(__dirname, '../..');
const source = fs.readFileSync(path.resolve(__dirname, '../KikiShield.user.js'), 'utf8');
const socketSource = cp.execFileSync('git', ['show', '5eb495c5ced4ee92d40385b7521e6ca63ace12e5:BondageClub/Scripts/lib/socket.io/socket.io.min.js'], { cwd: path.join(root, 'bc-client'), encoding: 'utf8' });

(async () => {
    const browser = await chromium.launch({ headless: true, ...(process.env.KIKISHIELD_CHROMIUM ? { executablePath: process.env.KIKISHIELD_CHROMIUM } : {}), args: ['--no-sandbox'] });
    try {
        const context = await browser.newContext({ viewport: { width: 1200, height: 800 }, hasTouch: true });
        await context.addInitScript({ content: source });
        let attemptedNetwork = 0;
        const html = `<!doctype html><html lang="en"><meta charset="utf-8"><title>KikiShield offline fixture</title><body style="background:#222735;color:white;font:20px system-ui"><p>Offline BC fixture</p><script>${socketSource}</script><script>
          var ServerSocket = null;
          var Player = {MemberNumber:100,CharacterID:'offline',AllowedInteractions:3,WhiteList:[200],BlackList:[],GhostList:[],Ownership:null,Lovership:[],Appearance:[{Name:'Accepted'}],ActivePose:[]};
          var ChatRoomCharacter = [{MemberNumber:200},{MemberNumber:300}];
          var ChatRoomData = {ID:'offline',Name:'Offline',Character:[]};
          var ChatRoomAllowCharacterUpdate = true;
          var ServerAppearanceBundle = a=>structuredClone(a);
          var corrections=0,ChatRoomCharacterUpdate=()=>corrections++;
          ServerSocket = new io.Manager('http://offline.invalid',{autoConnect:false}).socket('/');
          ServerSocket.connected=true;
          var delivered=0;ServerSocket.onAny(()=>delivered++);
        </script></body></html>`;
        await context.route('**/*', route => {
            if (route.request().url() === 'https://kikishield.test/') return route.fulfill({ contentType: 'text/html', body: html });
            attemptedNetwork++; return route.abort();
        });
        const page = await context.newPage(); const errors = []; page.on('pageerror', e => errors.push(e.message));
        await page.goto('https://kikishield.test/');
        await page.waitForFunction(() => window.KikiShield?.status().state === 'active');
        assert.equal(await page.evaluate(() => KikiShield.status().late), false);
        await page.evaluate(() => {
            ServerSocket.onevent({data:['ChatRoomMessage',{Sender:200,Type:'Hidden',Content:'BCC',Dictionary:{msg:'castSpell'}}]});
            ServerSocket.onevent({data:['ChatRoomMessage',{Sender:300,Type:'Chat',Content:'Ordinary'}]});
        });
        assert.equal(await page.evaluate(() => delivered), 1);
        await page.locator('#kikishield-root').locator('#badge').click();
        const shield = page.locator('#kikishield-root'), el = id => shield.locator('#' + id);
        assert.equal(await el('advanced').getAttribute('open'), null, 'Advanced settings start collapsed');
        assert.equal(await el('block-bcc').isChecked(), true);
        assert.equal(await el('block-lscg').isChecked(), false);
        assert.deepEqual(await page.evaluate(() => { const s=KikiShield.status().options; return [s.blockBCC,s.blockLSCG]; }), [true,false]);
        assert.match(await shield.locator('footer').innerText(), /Made By Kiki #72385/);
        await page.locator('#kikishield-root').locator('input[name="interaction"][value="whitelist"]').check();
        await el('advanced').locator('summary').click();
        await page.locator('#kikishield-root').locator('#hidden').check();
        assert.equal(await page.evaluate(() => KikiShield.status().options.interactionMode), 'whitelist');
        assert.equal(await page.evaluate(() => KikiShield.status().options.blockOtherHidden), true);
        await el('advanced').locator('summary').click();
        await page.screenshot({ path: path.join(root, 'kikishield-desktop.png') });
        await page.setViewportSize({ width: 390, height: 844 });
        await page.waitForFunction(() => {
            const b = document.getElementById('kikishield-root').shadowRoot.getElementById('panel').getBoundingClientRect();
            return b.x >= 0 && b.right <= innerWidth && b.bottom <= innerHeight;
        });
        const box = await page.locator('#kikishield-root').locator('#panel').boundingBox();
        assert(box && box.x >= 0 && box.x + box.width <= 390 && box.y + box.height <= 844, JSON.stringify(box));
        await page.screenshot({ path: path.join(root, 'kikishield-mobile.png') });
        const waitBounds = () => page.waitForFunction(() => {
            const b = document.getElementById('kikishield-root').shadowRoot.getElementById('panel').getBoundingClientRect();
            return b.x >= 0 && b.right <= innerWidth && b.y >= 0 && b.bottom <= innerHeight;
        });
        assert.equal(await el('badge').locator('img').evaluate(img => img.complete && img.naturalWidth === 1536 && img.src.startsWith('data:image/jpeg;base64,')), true);
        assert.equal(await shield.evaluate(host => /[\u0400-\u04ff]/.test(host.shadowRoot.textContent)), false);
        assert.equal(await el('badge').getAttribute('data-state'), 'active');
        await el('tab-protection').focus(); await page.keyboard.press('ArrowRight');
        assert.equal(await el('tab-automation').getAttribute('aria-selected'), 'true');
        assert.equal(await el('view-automation').isVisible(), true);
        await page.keyboard.press('ArrowRight');
        assert.equal(await el('tab-activity').getAttribute('aria-selected'), 'true');
        assert.equal(await el('view-protection').isVisible(), false);
        assert.match(await el('events').innerText(), /BCC · castSpell/);
        const [download] = await Promise.all([page.waitForEvent('download'), el('export').click()]);
        const exported = JSON.parse(fs.readFileSync(await download.path(), 'utf8'));
        assert.equal(exported.events[0].description, 'BCC command blocked');
        assert.match(exported.events[0].command, /castSpell/);
        assert.equal(exported.events[0].severity, 'caution');
        assert.equal(exported.events[0].detail, null, 'malformed command arguments are omitted');
        assert(!JSON.stringify(exported).includes('Ordinary'), 'ordinary chat is never exported');
        const previousTotal = await page.evaluate(() => KikiShield.status().blocked);
        await el('clear').click();
        assert.equal(await el('empty').isVisible(), true);
        assert.equal(await page.evaluate(() => KikiShield.status().blocked), previousTotal);
        await page.evaluate(() => {
            for (let i=0;i<6;i++) ServerSocket.onevent({data:['ChatRoomMessage',{Sender:200+i,Type:'Hidden',Content:i%2?'LSCGMsg':'BCC'}]});
        });
        await page.waitForFunction(() => document.getElementById('kikishield-root').shadowRoot.querySelectorAll('#events li').length === 6);
        await page.evaluate(() => { window.testFirstRow = document.getElementById('kikishield-root').shadowRoot.querySelector('#events li'); });
        await page.waitForTimeout(1100);
        assert.equal(await page.evaluate(() => window.testFirstRow === document.getElementById('kikishield-root').shadowRoot.querySelector('#events li')), true);
        await page.screenshot({ path: path.join(root, 'kikishield-activity.png') });
        await el('tab-protection').click();
        await el('advanced').locator('summary').click();
        for (const viewport of [{width:844,height:390},{width:320,height:568}]) {
            await page.setViewportSize(viewport); await waitBounds();
            assert.equal(await el('view-protection').evaluate(node => node.scrollWidth <= node.clientWidth), true);
            await el('hidden').uncheck(); await el('hidden').check();
            await page.screenshot({ path: path.join(root, viewport.width===844?'kikishield-landscape.png':'kikishield-small.png') });
        }
        await page.setViewportSize({width:390,height:844}); await waitBounds();
        await el('close').click();
        let badgeBox = await el('badge').boundingBox();
        const touch = await context.newCDPSession(page);
        const point = {x:badgeBox.x+badgeBox.width/2,y:badgeBox.y+badgeBox.height/2};
        await touch.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{...point,id:0}]});
        await touch.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:point.x-220,y:point.y+220,id:0}]});
        await touch.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
        assert.equal(await el('panel').isVisible(), false, 'Dragging must not open the menu');
        badgeBox = await el('badge').boundingBox();
        assert(badgeBox.x < 150 && badgeBox.y > 200, JSON.stringify(badgeBox));
        const movedBox = badgeBox;
        await el('badge').tap();
        await page.waitForFunction(() => !document.getElementById('kikishield-root').shadowRoot.getElementById('panel').hidden, null, {timeout:1500});
        assert.equal(await el('panel').isVisible(), true, 'Tap still works after dragging');
        await page.keyboard.press('Escape');
        assert.equal(await el('panel').isVisible(), false);
        assert.equal(await shield.evaluate(host => host.shadowRoot.activeElement.id), 'badge');
        await page.keyboard.press('Enter'); assert.equal(await el('panel').isVisible(), true);
        await page.keyboard.press('Escape');
        await page.keyboard.press('Space'); assert.equal(await el('panel').isVisible(), true);
        await page.keyboard.press('Escape');
        await el('badge').tap(); await page.mouse.click(2,600);
        assert.equal(await el('panel').isVisible(), false, 'Outside click closes the menu');
        await page.reload(); await page.waitForFunction(() => window.KikiShield?.status().state === 'active');
        assert.equal(await page.evaluate(() => KikiShield.status().options.interactionMode), 'whitelist');
        badgeBox = await el('badge').boundingBox();
        assert(Math.abs(badgeBox.x-movedBox.x)<2 && Math.abs(badgeBox.y-movedBox.y)<2, 'Launcher position survives reload');
        await el('badge').tap(); await el('reset-position').click();
        badgeBox = await el('badge').boundingBox(); assert(badgeBox.x>300 && badgeBox.y===12);
        await el('advanced').locator('summary').click();
        await el('restore').uncheck();
        assert.equal(await page.evaluate(() => KikiShield.status().options.restoreAppearance), false);
        await el('block-bcc').uncheck(); await el('block-lscg').check(); await el('graphics').uncheck();
        assert.deepEqual(await page.evaluate(() => { const s=KikiShield.status().options; return [s.blockBCC,s.blockLSCG]; }), [false,true]);
        assert.equal(await page.evaluate(() => KikiShield.status().graphics.state), 'off');
        assert.deepEqual(await page.evaluate(() => { const s=JSON.parse(localStorage.getItem('KikiShield.v1.100')); return [s.blockBCC,s.blockLSCG,s.guardGraphics]; }), [false,true,false]);
        await el('advanced').locator('summary').click();
        await page.evaluate(() => {
            const existing = document.createElement('audio'); existing.id='existing-media'; existing.muted=false;
            const premuted = document.createElement('audio'); premuted.id='premuted-media'; premuted.muted=true;
            const outside = document.createElement('button'); outside.id='outside-control'; outside.textContent='Outside control';
            const inert = document.createElement('div'); inert.id='already-inert'; inert.inert=true;
            document.body.append(existing,premuted,outside,inert);
            window.beforePanic={delivered,corrections};
        });
        await el('panic-button').click();
        await page.waitForFunction(() => KikiShield.status().panic?.active === true);
        assert.equal(await el('panic-screen').isVisible(), true);
        assert.equal(await el('panel').isVisible(), false); assert.equal(await el('badge').isVisible(), false);
        assert.equal(await page.evaluate(() => document.documentElement.hasAttribute('data-kikishield-panic')), true);
        assert.equal(await page.locator('#outside-control').evaluate(node => node.inert), true);
        await page.waitForFunction(() => document.getElementById('existing-media').muted);
        assert.equal(await page.locator('#premuted-media').evaluate(node => node.muted), true);
        assert.match(await el('panic-description').innerText(), /independent addon audio may continue/);
        assert.equal(await page.evaluate(() => corrections === window.beforePanic.corrections), true, 'Panic activation sends no appearance update');
        await page.evaluate(() => {
            ServerSocket.onevent({data:['ChatRoomMessage',{Sender:200,Type:'Chat',Content:'Hidden by Panic'}]});
            ServerSocket.onevent({data:['ChatRoomMessage',{Sender:100,Type:'Chat',Content:'Own chat echo'}]});
            ServerSocket.onevent({data:['AccountBeep',{MemberNumber:300,Message:'Quiet please'}]});
            const fresh=document.createElement('video'); fresh.id='panic-new-media'; fresh.muted=false;
            document.body.append(fresh);
        });
        assert.equal(await page.evaluate(() => delivered === window.beforePanic.delivered), true, 'Panic stops incoming chat and beeps before listeners');
        await page.waitForFunction(() => document.getElementById('panic-new-media').muted && document.getElementById('panic-new-media').inert);
        await el('panic-resume').focus(); await page.keyboard.press('Tab');
        assert.equal(await shield.evaluate(host => host.shadowRoot.activeElement.id), 'panic-resume');
        await page.keyboard.press('Shift+Tab');
        assert.equal(await shield.evaluate(host => host.shadowRoot.activeElement.id), 'panic-resume');
        await page.keyboard.press('Escape');
        assert.equal(await page.evaluate(() => KikiShield.status().panic.active), true, 'Escape does not accidentally dismiss Panic');
        await page.evaluate(() => {
            const leakHost=document.createElement('div'); leakHost.id='panic-shadow-host';
            leakHost.style.cssText='position:fixed;inset:0;z-index:2147483647;visibility:visible!important';
            leakHost.attachShadow({mode:'open'}).innerHTML='<div style="visibility:visible!important;position:fixed;inset:0;background:#ff00ff">Private addon content</div>';
            document.body.append(leakHost);
            const other=document.createElement('dialog'); other.id='other-addon-dialog';
            other.style.cssText='width:90vw;height:90vh;background:#ff00ff'; other.textContent='Other addon modal';
            document.body.append(other); other.showModal();
        });
        const resumeOnTop = () => {
            const host=document.getElementById('kikishield-root'), shadow=host.shadowRoot;
            const button=shadow.getElementById('panic-resume'), box=button.getBoundingClientRect();
            const x=box.x+box.width/2,y=box.y+box.height/2;
            return shadow.getElementById('panic-screen').matches(':modal') &&
                document.elementFromPoint(x,y)===host && shadow.elementFromPoint(x,y)===button;
        };
        await page.waitForFunction(resumeOnTop);
        assert.equal(await page.locator('#other-addon-dialog').evaluate(node => node.open), true, 'Panic must not close another addon dialog');
        assert.equal(await page.locator('#panic-shadow-host').evaluate(node => getComputedStyle(node).opacity), '0', 'Root opacity hides shadow descendants that force visibility');
        assert.equal(await page.locator('#panic-shadow-host').evaluate(node => getComputedStyle(node.shadowRoot.firstElementChild).visibility), 'visible', 'Regression fixture really defeats inherited visibility');
        const supportsPopover=await page.evaluate(() => typeof HTMLElement.prototype.showPopover==='function');
        if (supportsPopover) {
            await page.evaluate(() => {
                const popover=document.createElement('div'); popover.id='other-addon-popover'; popover.popover='manual';
                popover.style.cssText='position:fixed;inset:0;width:100vw;height:100vh;background:#ff00ff';
                popover.textContent='Other addon popover'; document.body.append(popover); popover.showPopover();
            });
            await page.waitForFunction(resumeOnTop);
        }
        await page.screenshot({ path: path.join(root, 'kikishield-panic.png') });
        await el('panic-resume').click();
        assert.equal(await page.evaluate(() => KikiShield.status().panic.active), false);
        assert.equal(await el('panic-screen').isVisible(), false); assert.equal(await el('badge').isVisible(), true);
        assert.equal(await page.evaluate(() => document.documentElement.hasAttribute('data-kikishield-panic')), false);
        assert.equal(await page.locator('#outside-control').evaluate(node => node.inert), false);
        assert.equal(await page.locator('#already-inert').evaluate(node => node.inert), true);
        assert.equal(await page.locator('#existing-media').evaluate(node => node.muted), false);
        assert.equal(await page.locator('#premuted-media').evaluate(node => node.muted), true);
        assert.equal(await page.locator('#panic-new-media').evaluate(node => node.muted), false);
        await page.evaluate(() => ServerSocket.onevent({data:['ChatRoomMessage',{Sender:300,Type:'Chat',Content:'Back to normal'}]}));
        assert.equal(await page.evaluate(() => delivered === window.beforePanic.delivered+1), true);
        assert.equal(await page.evaluate(() => corrections === window.beforePanic.corrections), true, 'Panic resume sends no appearance update');
        assert.equal(await page.locator('#other-addon-dialog').evaluate(node => node.open), true, 'Resume preserves the other addon modal');
        assert.equal(await page.locator('#other-addon-dialog').evaluate(node => node.inert), false);
        assert.equal(await page.locator('#panic-shadow-host').evaluate(node => getComputedStyle(node).opacity), '1', 'Resume restores addon content visibility');
        await page.evaluate(() => {
            document.getElementById('panic-shadow-host').remove();
            document.getElementById('other-addon-popover')?.remove();
            // The pre-existing modal intentionally prevents pointer access to the launcher.
            // Trigger the same UI callback to check the already-open-modal activation path.
            document.getElementById('kikishield-root').shadowRoot.getElementById('panic-button').click();
        });
        await page.waitForFunction(resumeOnTop);
        assert.equal(await page.locator('#other-addon-dialog').evaluate(node => node.open), true);
        await el('panic-resume').click();
        assert.equal(await page.evaluate(() => KikiShield.status().panic.active), false);
        assert.equal(await page.locator('#other-addon-dialog').evaluate(node => node.open), true, 'Repeated Panic keeps an existing modal open');
        assert.equal(await page.locator('#other-addon-dialog').evaluate(node => node.inert), false);
        await page.locator('#other-addon-dialog').evaluate(node => { node.close(); node.remove(); });
        if (!await el('panel').isVisible()) await el('badge').click();
        await page.addScriptTag({ content: source });
        assert.equal(await page.locator('#kikishield-root').count(), 1);
        await page.evaluate(() => { ServerSocket.emitEvent = function() {}; });
        await page.waitForFunction(() => KikiShield.status().state === 'degraded');
        await page.waitForFunction(() => document.getElementById('kikishield-root').shadowRoot.getElementById('badge').dataset.state === 'degraded');
        assert.equal(await el('warning').isVisible(), true); await waitBounds();
        assert.deepEqual(errors, []); assert.equal(attemptedNetwork, 0);
        const report = { browser: browser.version(), checks: [
            'document-start before var ServerSocket declaration', 'real Socket.IO before onAny',
            'normal chat pass-through', 'settings UI', 'mobile panel bounds', 'preferences survive reload',
            'duplicate injection prevented', 'modified transport detected', 'no browser errors', 'no external network requests',
            'provided icon decodes without a remote request', 'English-only interface', 'status indicator follows filter state',
            'keyboard-accessible tabs', 'English event export includes command labels and severity, excludes ordinary chat', 'clear log preserves session totals',
            'idle activity does not rebuild log nodes', 'landscape and small-screen scroll without horizontal overflow',
            'touch drag does not trigger a tap', 'tap opens after dragging', 'Escape restores launcher focus',
            'outside click closes', 'launcher position persists', 'reset launcher position',
            'appearance restore toggle controls the existing option', 'degraded notice remains visible and inside viewport',
            'launcher opens with Enter and Space', 'independent addon blocking options and persistence', 'image recovery option and persistence',
            'advanced controls start collapsed', 'BCC on and LSCG off by default', 'creator credit displayed',
            'Panic hides page and launcher behind an opaque curtain', 'Panic marks existing and new page children inert',
            'Panic blocks chat and beeps before listeners', 'Panic mutes existing and new page media',
            'Panic contains keyboard focus and requires explicit Resume', 'Panic restores media mute and inert states',
            'Panic activation and resume send no appearance update', 'normal chat resumes after Panic',
            'Panic remains above newly opened addon dialogs', 'Panic remains above supported popovers',
            'Panic opacity hides shadow descendants that force visibility', 'Resume and repeated Panic preserve existing addon modals'
        ], passed: 44, screenshots: ['kikishield-desktop.png','kikishield-mobile.png','kikishield-activity.png','kikishield-landscape.png','kikishield-small.png','kikishield-panic.png'] };
        fs.writeFileSync(path.join(__dirname,'browser-results.json'),JSON.stringify(report,null,2)+'\n');
        console.log(JSON.stringify(report,null,2));
    } finally { await browser.close(); }
})().catch(e => { console.error(e); process.exitCode = 1; });
