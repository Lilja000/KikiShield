'use strict';
const createShield = require('../KikiShield.user.js');
class TestSocket {
    constructor() { this.connected = false; this.receiveBuffer = []; this.handlers = new Map(); this.any = []; }
    on(name, fn) { const a = this.handlers.get(name) || []; a.push(fn); this.handlers.set(name, a); return this; }
    onAny(fn) { this.any.push(fn); return this; }
    emitEvent(args) { for (const f of this.any) f(...args); for (const f of this.handlers.get(args[0]) || []) f(...args.slice(1)); }
    onevent(packet) { const args = packet.data || []; if (this.connected) this.emitEvent(args); else this.receiveBuffer.push(Object.freeze(args)); }
    emitBuffered() { this.receiveBuffer.forEach(args => this.emitEvent(args)); this.receiveBuffer = []; }
}
function harness(makeSocket = () => new TestSocket(), stored = new Map(), compatibility = true) {
    const timeouts = new Map(); let tid = 0;
    const writes = [];
    const W = {
        Player: { MemberNumber: 100, CharacterID: 'own', AllowedInteractions: 3, WhiteList: [200], BlackList: [], GhostList: [],
            Lovership: [], Ownership: null, Reputation: [{ Type: 'Dominant', Value: 0 }], Appearance: [{ Name: 'Accepted', Group: 'Test' }], ActivePose: ['Base'] },
        ChatRoomData: { ID: 'offline', Name: 'Offline', Character: [] },
        ChatRoomCharacter: [{ MemberNumber: 200, WhiteList: [100], Reputation: [] }, { MemberNumber: 300, WhiteList: [100], Reputation: [] }],
        ServerSocket: null, ChatRoomAllowCharacterUpdate: true,
        ServerAppearanceBundle: appearance => structuredClone(appearance),
        ChatRoomCharacterUpdate: p => writes.push(structuredClone(p)),
        localStorage: { getItem: k => stored.get(k), setItem: (k, v) => stored.set(k, v) },
        setTimeout: fn => { timeouts.set(++tid, fn); return tid; }, clearTimeout: id => timeouts.delete(id),
        setInterval: () => 999, clearInterval: () => {}
    };
    const shield = createShield(W).start();
    // Historical positive-path tests exercise the optional BCC compatibility mode.
    // New default-isolation tests explicitly pass compatibility=false.
    if (compatibility) shield.configure({ blockBCC: false });
    const socket = makeSocket(); W.ServerSocket = socket; socket.connected = true;
    return { W, shield, socket, writes, stored, receive: (event, data) => socket.onevent({ type: 2, data: [event, data] }),
        flush: () => { const tasks = [...timeouts.values()]; timeouts.clear(); tasks.forEach(fn => fn()); } };
}
const chat = (changes = {}) => ({ Sender: 300, Type: 'Chat', Content: 'Synthetic message', ...changes });
const item = (source = 300, target = 100) => ({ Source: source, Item: { Target: target, Group: 'Test', Name: 'Unaccepted' } });
module.exports = { harness, TestSocket, chat, item };
