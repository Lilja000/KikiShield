'use strict';
// New Activity and automatic list-action regressions. Native relation side effects
// below are exercised using the audited R132 implementation, not a look-alike API.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { harness, chat, item } = require('./harness.cjs');
const root = process.env.KIKISHIELD_UPSTREAM || path.resolve(__dirname, '../..');
const nativeSource = fs.readFileSync(path.join(root, 'shield-hardening-audit/R132-Screens_Online_ChatRoom_ChatRoom.js'), 'utf8');
const triggerStart = nativeSource.indexOf('const ChatRoomListOperationTriggers = () => [');
const triggerEnd = nativeSource.indexOf('\n];', triggerStart) + 4;
const updateStart = nativeSource.indexOf('function ChatRoomListUpdate(');
const updateEnd = nativeSource.indexOf('\n/**', updateStart);
assert(triggerStart >= 0 && triggerEnd > triggerStart && updateStart >= 0 && updateEnd > updateStart);

const bcc = (id, msg = 'syncStorage', data = { storage: { version: '2.2.3' } }) => chat({
    Sender: id, Type: 'Hidden', Content: 'BCC', Dictionary: { msg, data }
});
const relay = (id = 300, changes = {}) => bcc(id, 'animaFurtaCommand', {
    name: 'changeAppearance', target: 100, appearance: [{ Name: 'ForeignRestraint', Group: 'ItemArms' }], ...changes
});
const lscgSync = (id = 300) => chat({ Sender: id, Content: 'LSCGMsg', Type: 'Hidden',
    Dictionary: [{ message: { IsLSCG: true, version: '0.9.8', type: 'sync', settings: { Enabled: true }, reply: false } }] });
const rowsFor = (h, event) => h.shield.getLog().filter(x => x.event === event);
const latest = (h, event) => rowsFor(h, event).at(-1);
function fixture(options = {}) {
    const h = harness(undefined, undefined, false);
    h.W.Player.FriendList = [];
    h.calls = []; h.relationSyncs = []; h.sent = [];
    const env = {
        Player: h.W.Player, Character: h.W.ChatRoomCharacter,
        CommonIsNonNegativeInteger: n => Number.isInteger(n) && n >= 0,
        CharacterRefresh() {},
        ServerSend: (...args) => h.sent.push(args),
        ServerPlayerRelationsSync: () => h.relationSyncs.push({
            account: env.Player.MemberNumber,
            black: [...env.Player.BlackList], ghost: [...env.Player.GhostList], white: [...env.Player.WhiteList]
        })
    };
    vm.createContext(env);
    vm.runInContext(nativeSource.slice(triggerStart, triggerEnd) + '\n' + nativeSource.slice(updateStart, updateEnd), env);
    h.W.ChatRoomListUpdate = (list, adding, memberNumber, notification, sync) => {
        const p = h.W.Player;
        const name = ['BlackList', 'GhostList', 'WhiteList', 'FriendList'].find(k => p[k] === list);
        assert(name, 'native API must receive one of the actual Player relation arrays');
        assert.equal(typeof adding, 'boolean');
        assert(Number.isInteger(memberNumber));
        h.calls.push({ name, adding, memberNumber, notification, sync });
        env.Player = p; env.Character = h.W.ChatRoomCharacter;
        return env.ChatRoomListUpdate(list, adding, memberNumber, notification, sync);
    };
    h.shield.configure(options);
    return h;
}
function attack(h, sender = 300, change = {}) {
    h.receive('ChatRoomSyncItem', { ...item(sender), Item: { ...item(sender).Item, ...change } });
}
function actionRow(h) {
    const row = h.shield.getLog().find(x => x.autoActionId != null);
    assert(row, 'a performed automatic list action must have an undo identifier in Activity');
    return row;
}

// Activity is useful evidence without becoming a transcript of private chat.
test('Activity captures the exact blocked item and labels the unauthorized targeted change serious', () => {
    const h = fixture(); const packet = item();
    packet.Item.Property = { Difficulty: 7, CustomName: '<img src=x onerror=alert(1)>' };
    h.receive('ChatRoomSyncItem', packet);
    const row = latest(h, 'ChatRoomSyncItem');
    assert.equal(row.severity, 'serious'); assert.equal(row.sender, 300); assert.equal(row.target, 100);
    assert(row.id != null); assert.equal(typeof row.command, 'string'); assert(row.command.length);
    assert.equal(typeof row.summary, 'string'); assert(row.summary.length);
    assert.equal(typeof row.explanation, 'string'); assert(row.explanation.length);
    assert.equal(typeof row.detail, 'string'); assert.doesNotThrow(() => JSON.parse(row.detail));
    assert.match(row.detail, /Unaccepted/); assert.match(row.detail, /Difficulty/); assert.match(row.detail, /onerror/);
    assert.equal(row.detailTruncated, false);
    packet.Item.Name = 'CHANGED_AFTER_RECEIVE';
    assert(!latest(h, 'ChatRoomSyncItem').detail.includes('CHANGED_AFTER_RECEIVE'));
});

test('BCC relay command remains serious evidence while default BCC isolation is enabled', () => {
    const h = fixture(); h.receive('ChatRoomMessage', relay());
    const row = latest(h, 'ChatRoomMessage');
    assert.equal(row.addon, 'BCC'); assert.equal(row.severity, 'serious');
    assert.match(row.command, /animaFurtaCommand|changeAppearance/);
    assert.match(row.detail, /changeAppearance/); assert.match(row.detail, /ForeignRestraint/);
});

test('Routine BCC metadata is background traffic, not an accusation of a bypass attempt', () => {
    const h = fixture(); h.receive('ChatRoomMessage', bcc(300));
    const row = latest(h, 'ChatRoomMessage');
    assert.equal(row.addon, 'BCC'); assert.equal(row.severity, 'background');
    assert.match(row.command, /syncStorage/);
});

test('Different commands and payloads do not collapse into one Activity row; identical duplicates do', () => {
    const h = fixture();
    h.receive('ChatRoomMessage', relay());
    h.receive('ChatRoomMessage', relay(300, { appearance: [{ Name: 'Different', Group: 'ItemArms' }] }));
    h.receive('ChatRoomMessage', relay(300, { name: 'publishAction', params: { Type: 'Hidden', Content: 'Fixture' } }));
    const before = rowsFor(h, 'ChatRoomMessage'); assert.equal(before.length, 3);
    assert.equal(new Set(before.map(x => x.id)).size, 3);
    const lastId = before.at(-1).id;
    h.receive('ChatRoomMessage', relay(300, { name: 'publishAction', params: { Type: 'Hidden', Content: 'Fixture' } }));
    const after = rowsFor(h, 'ChatRoomMessage'); assert.equal(after.length, 3);
    assert.equal(after.at(-1).id, lastId); assert.equal(after.at(-1).count, 2);
});

test('Blocked ordinary chat and Panic traffic never retain conversation text', () => {
    const h = fixture(); h.W.Player.BlackList = [300];
    h.receive('ChatRoomMessage', chat({ Content: 'PRIVATE_NORMAL_CHAT_8469' }));
    h.receive('AccountBeep', { MemberNumber: 300, Message: 'PRIVATE_BEEP_9470' });
    h.shield.setPanic(true);
    h.receive('ChatRoomMessage', chat({ Sender: 200, Content: 'PRIVATE_PANIC_CHAT_2546' }));
    h.receive('ChatRoomMessage', relay(200, { message: 'PRIVATE_PANIC_COMMAND_4583' }));
    const json = JSON.stringify(h.shield.getLog());
    for (const secret of ['PRIVATE_NORMAL_CHAT_8469', 'PRIVATE_BEEP_9470', 'PRIVATE_PANIC_CHAT_2546', 'PRIVATE_PANIC_COMMAND_4583'])
        assert(!json.includes(secret), secret + ' must not survive in any Activity field');
    for (const row of h.shield.getLog().filter(x => x.reason === 'panic')) assert.equal(row.detail, null);
});

test('System repair notifications have system severity', () => {
    const h = fixture(); attack(h); h.flush();
    const row = h.shield.getLog().find(x => x.reason === 'repair');
    assert(row); assert.equal(row.severity, 'system');
});

test('Activity snapshots are detached and Clear removes captured commands', () => {
    const h = fixture(); attack(h);
    const external = h.shield.getLog(); const original = structuredClone(external);
    external[0].summary = 'FORGED'; external[0].detail = 'FORGED'; external.push({ id: 'FORGED' });
    assert.deepEqual(h.shield.getLog(), original);
    h.shield.clearLog(); assert.deepEqual(h.shield.getLog(), []);
});

test('Captured command details have finite per-event and total memory limits', () => {
    const h = fixture();
    for (let n = 0; n < 100; n++) h.receive('ChatRoomMessage', relay(300, { message: String(n) + '😀'.repeat(20000) }));
    const rows = h.shield.getLog(); assert(rows.length <= 100);
    const sizes = rows.map(row => Buffer.byteLength(row.detail || '', 'utf8'));
    assert(sizes.every(n => n <= 65536), 'details are capped at 64 KiB including non-ASCII UTF-8');
    assert(sizes.reduce((a, b) => a + b, 0) <= 1048576, 'details are capped at 1 MiB in total');
    assert(rows.some(row => row.detailTruncated || row.detailNote), 'omissions must be explicitly disclosed');
});

// Automatic list actions are opt-in and use the observed server envelope identity.
test('Automatic actions are off by default, with conservative configurable trigger defaults', () => {
    const h = fixture(); const opts = h.shield.status().options;
    assert.equal(opts.autoAction, 'off'); assert.equal(opts.autoOnViolation, true);
    assert.equal(opts.autoOnBCC, false); assert.equal(opts.autoOnLSCG, false);
    assert.equal(opts.autoThreshold, 1); assert.equal(opts.autoProtectTrusted, true);
    assert.deepEqual(opts.autoExceptions, []);
    attack(h); h.receive('ChatRoomMessage', relay()); h.flush();
    assert.deepEqual(h.calls, []); assert.deepEqual(h.W.Player.BlackList, []);
    assert.equal(typeof h.shield.status().automation, 'object');
});

test('One direct forbidden item update queues one native blacklist action without notifying the sender', () => {
    const h = fixture({ autoAction: 'blacklist' });
    attack(h); assert.deepEqual(h.W.Player.BlackList, [], 'the receive stack must not mutate relations');
    h.flush(); assert.deepEqual(h.W.Player.BlackList, [300]);
    assert.equal(h.calls.filter(x => x.name === 'BlackList' && x.adding).length, 1);
    assert(h.relationSyncs.some(x => x.black.includes(300)));
    assert.deepEqual(h.sent, []); assert.equal(actionRow(h).autoAction, 'blacklist');
});

test('Ghost actions use native semantics and synchronize both ghost and blacklist', () => {
    const h = fixture({ autoAction: 'ghost' }); attack(h); h.flush();
    assert.deepEqual(h.W.Player.GhostList, [300]); assert.deepEqual(h.W.Player.BlackList, [300]);
    assert(h.relationSyncs.some(x => x.ghost.includes(300) && x.black.includes(300)));
    assert.equal(actionRow(h).autoAction, 'ghost');
});

test('Undo of a new ghost action removes only entries created by that action', () => {
    const h = fixture({ autoAction: 'ghost' }); attack(h); h.flush();
    const row = actionRow(h); h.shield.undoAutoAction(row.autoActionId); h.flush();
    assert.deepEqual(h.W.Player.GhostList, []); assert.deepEqual(h.W.Player.BlackList, []);
    const callsAfter = h.calls.length;
    h.shield.undoAutoAction(row.autoActionId); h.flush(); assert.equal(h.calls.length, callsAfter);
});

test('Undo ghost preserves a blacklist entry that existed before the automatic action', () => {
    const h = fixture({ autoAction: 'ghost' }); h.W.Player.BlackList = [300];
    attack(h); h.flush(); assert.deepEqual(h.W.Player.GhostList, [300]);
    const row = actionRow(h); h.shield.undoAutoAction(row.autoActionId); h.flush();
    assert.deepEqual(h.W.Player.GhostList, []); assert.deepEqual(h.W.Player.BlackList, [300]);
    assert(h.relationSyncs.at(-1).black.includes(300));
});

test('Duplicate packets and already-listed senders cannot repeatedly synchronize lists', () => {
    const h = fixture({ autoAction: 'blacklist' });
    for (let n = 0; n < 40; n++) attack(h);
    h.flush(); const calls = h.calls.length;
    for (let n = 0; n < 40; n++) attack(h);
    h.flush(); assert.equal(h.calls.length, calls); assert.equal(calls, 1);
});

test('Only serious violations contribute to the configured threshold', () => {
    const h = fixture({ autoAction: 'blacklist', autoThreshold: 2 });
    for (let n = 0; n < 10; n++) h.receive('ChatRoomMessage', bcc(300));
    attack(h); h.flush(); assert.deepEqual(h.W.Player.BlackList, []);
    attack(h, 300, { Name: 'SecondDistinctChange' }); h.flush();
    assert.deepEqual(h.W.Player.BlackList, [300]);
});

test('Threshold counters expire after sixty seconds', () => {
    const realNow = Date.now; let clock = 1000000; Date.now = () => clock;
    try {
        const h = fixture({ autoAction: 'blacklist', autoThreshold: 2 });
        attack(h); h.flush(); clock += 60001;
        attack(h, 300, { Name: 'AfterExpiry' }); h.flush(); assert.deepEqual(h.W.Player.BlackList, []);
        attack(h, 300, { Name: 'WithinCurrentWindow' }); h.flush(); assert.deepEqual(h.W.Player.BlackList, [300]);
    } finally { Date.now = realNow; }
});

test('Routine BCC presence never causes a ban with the default violation-only trigger', () => {
    const h = fixture({ autoAction: 'blacklist' });
    for (let n = 0; n < 10; n++) h.receive('ChatRoomMessage', bcc(300));
    h.flush(); assert.deepEqual(h.calls, []);
});

test('Explicit BCC-presence option handles observed BCC traffic independently of violation count', () => {
    const h = fixture({ autoAction: 'blacklist', autoOnViolation: false, autoOnBCC: true, autoThreshold: 3 });
    h.receive('ChatRoomMessage', bcc(300)); h.flush(); assert.deepEqual(h.W.Player.BlackList, [300]);
});

test('Explicit LSCG-presence option detects allowed metadata while LSCG isolation remains off', () => {
    const h = fixture({ autoAction: 'ghost', autoOnViolation: false, autoOnLSCG: true });
    let delivered = 0; h.socket.on('ChatRoomMessage', () => delivered++);
    h.receive('ChatRoomMessage', lscgSync());
    assert.equal(delivered, 1); h.flush(); assert.deepEqual(h.W.Player.GhostList, [300]);
});

for (const [name, setRelation] of [
    ['friend', p => { p.FriendList = [300]; }], ['owner', p => { p.Ownership = { MemberNumber: 300 }; }],
    ['lover', p => { p.Lovership = [{ MemberNumber: 300 }]; }], ['whitelist', p => { p.WhiteList = [300]; }]
]) test('Trusted protection exempts own ' + name + ' from optional BCC-presence enforcement', () => {
    const h = fixture({ autoAction: 'ghost', autoOnBCC: true }); setRelation(h.W.Player);
    h.receive('ChatRoomMessage', relay()); h.receive('ChatRoomMessage', bcc(300)); h.flush();
    assert.deepEqual(h.calls, []);
});

test('Trusted protection can be explicitly disabled', () => {
    const h = fixture({ autoAction: 'blacklist', autoOnBCC: true, autoProtectTrusted: false });
    h.W.Player.FriendList = [300]; h.receive('ChatRoomMessage', bcc(300)); h.flush();
    assert.deepEqual(h.W.Player.BlackList, [300]);
});

test('Exception IDs exclude both violation and addon-presence triggers', () => {
    const h = fixture({ autoAction: 'ghost', autoOnBCC: true, autoExceptions: [300] });
    attack(h); h.receive('ChatRoomMessage', relay()); h.receive('ChatRoomMessage', bcc(300)); h.flush();
    assert.deepEqual(h.calls, []);
});

test('Invalid and huge exception settings are bounded and cannot enable an invalid action', () => {
    const h = fixture({ autoAction: 'INVALID', autoThreshold: 999, autoExceptions: Array.from({ length: 150 }, (_, i) => i + 1000) });
    const opts = h.shield.status().options;
    assert.equal(opts.autoAction, 'off'); assert([1, 2, 3].includes(opts.autoThreshold));
    assert(opts.autoExceptions.length <= 100); assert(opts.autoExceptions.every(Number.isInteger));
    attack(h); h.flush(); assert.deepEqual(h.calls, []);
});

for (const sender of [undefined, null, '300', -1, NaN, 900, 100]) test('Invalid, unobserved, or self sender cannot be auto-listed: ' + String(sender), () => {
    const h = fixture({ autoAction: 'ghost', autoOnBCC: true, autoOnLSCG: true, autoProtectTrusted: false });
    h.receive('ChatRoomMessage', { ...relay(), Sender: sender });
    h.receive('ChatRoomSyncItem', { Source: sender, Item: { Target: 100, Group: 'Test', Name: 'Bad' } });
    h.flush(); assert.deepEqual(h.calls, []);
});

test('Native updates to other characters do not count as a violation against this account', () => {
    const h = fixture({ autoAction: 'blacklist' });
    h.receive('ChatRoomSyncItem', item(300, 200));
    h.receive('ChatRoomSyncSingle', { SourceMemberNumber: 300, Character: { MemberNumber: 200, Appearance: [{ Name: 'Changed' }] } });
    h.flush(); assert.deepEqual(h.calls, []);
});

test('Unchanged own-character item data and full appearance echoes cannot cause false enforcement', () => {
    const h = fixture({ autoAction: 'blacklist' });
    h.receive('ChatRoomSyncItem', { Source: 300, Item: { Target: 100, Group: 'Test', Name: 'Accepted' } });
    h.receive('ChatRoomSyncSingle', { SourceMemberNumber: 300, Character: {
        MemberNumber: 100, Appearance: structuredClone(h.W.Player.Appearance), ActivePose: ['Base']
    } });
    h.flush(); assert.deepEqual(h.calls, []);
});

test('Room snapshots and server relationship refreshes never attribute every change to their source', () => {
    const h = fixture({ autoAction: 'blacklist' });
    h.receive('ChatRoomSync', { SourceMemberNumber: 300, Character: [{ MemberNumber: 100, Appearance: [{ Name: 'Changed' }] }] });
    h.receive('ChatRoomSyncCharacter', { SourceMemberNumber: 300, Character: {
        MemberNumber: 100, Appearance: [{ Name: 'Changed' }], Ownership: { MemberNumber: 500 }
    } });
    h.flush(); assert.deepEqual(h.calls, []);
});

test('Changing the logged-in account cancels queued automatic actions', () => {
    const h = fixture({ autoAction: 'ghost' }); attack(h);
    h.W.Player = { ...h.W.Player, MemberNumber: 400, BlackList: [], GhostList: [], WhiteList: [] };
    h.shield.tick(); h.flush(); assert.deepEqual(h.calls, []);
    assert.deepEqual(h.W.Player.BlackList, []); assert.deepEqual(h.W.Player.GhostList, []);
});

test('Changing options or adding an exception before queue flush cancels enforcement', () => {
    for (const option of [{ autoAction: 'off' }, { autoExceptions: [300] }]) {
        const h = fixture({ autoAction: 'blacklist' }); attack(h); h.shield.configure(option); h.flush();
        assert.deepEqual(h.calls, []);
    }
});

test('Panic never queues punitive automatic list actions, including appearance traffic', () => {
    const h = fixture({ autoAction: 'ghost', autoOnBCC: true, autoOnLSCG: true }); h.shield.setPanic(true);
    attack(h); h.receive('ChatRoomMessage', relay()); h.receive('ChatRoomMessage', bcc(300));
    h.receive('ChatRoomMessage', lscgSync()); h.flush(); assert.deepEqual(h.calls, []);
});

test('Missing or failing native relation API cannot crash delivery of unrelated legitimate traffic', () => {
    for (const nativeAPI of [undefined, () => { throw new Error('synthetic unavailable native relation API'); }]) {
        const h = fixture({ autoAction: 'blacklist' }); h.W.ChatRoomListUpdate = nativeAPI;
        let delivered = 0; h.socket.on('ChatRoomMessage', () => delivered++);
        assert.doesNotThrow(() => { attack(h); h.flush(); h.receive('ChatRoomMessage', chat({ Sender: 200 })); });
        assert.equal(delivered, 1); assert.deepEqual(h.W.Player.BlackList, []);
        assert(!h.shield.getLog().some(x => x.autoAction === 'blacklist' && x.autoActionId != null));
    }
});

test('Payload member numbers cannot redirect enforcement away from the trusted outer sender', () => {
    const h = fixture({ autoAction: 'ghost', autoOnBCC: true });
    const forged = relay(200); forged.Dictionary.data.Sender = 300;
    forged.Dictionary.data.castedBy = { id: 300 }; forged.Dictionary.data.createdBy = { id: 300 };
    h.receive('ChatRoomMessage', forged); h.flush();
    assert.deepEqual(h.calls, [], 'our whitelisted outer sender cannot frame the ID written inside payload data');
});

test('LSCG command for a foreign target is rejected without accusing the sender of targeting this player', () => {
    const h = fixture({ autoAction: 'ghost' });
    h.receive('ChatRoomMessage', chat({ Sender: 300, Content: 'LSCGMsg', Type: 'Hidden', Dictionary: [{
        message: { type: 'command', target: 200, command: { name: 'spell', args: [] } }
    }] }));
    h.flush(); assert.deepEqual(h.calls, []);
});

test('Automatic enforcement rechecks new trusted relationships and Panic before queue execution', () => {
    for (const beforeFlush of [h => { h.W.Player.FriendList = [300]; }, h => h.shield.setPanic(true)]) {
        const h = fixture({ autoAction: 'ghost' }); attack(h); beforeFlush(h); h.flush();
        assert.deepEqual(h.calls, []);
    }
});

test('Disabling the specific presence trigger cancels its queued action', () => {
    const h = fixture({ autoAction: 'blacklist', autoOnViolation: false, autoOnBCC: true });
    h.receive('ChatRoomMessage', bcc(300)); h.shield.configure({ autoOnBCC: false }); h.flush();
    assert.deepEqual(h.calls, []);
});

test('Cyclic and malformed command detail cannot crash Activity serialization', () => {
    const h = fixture(); const packet = relay(); packet.Dictionary.data.loop = packet;
    assert.doesNotThrow(() => h.receive('ChatRoomMessage', packet));
    assert.doesNotThrow(() => JSON.stringify(h.shield.getLog()));
    assert(h.shield.getLog().every(row => row.detail == null || Buffer.byteLength(row.detail, 'utf8') <= 65536));
});

test('Automatic actions stop at five per minute and do not execute later without a new event', () => {
    const realNow = Date.now; let clock = 2000000; Date.now = () => clock;
    try {
        const h = fixture({ autoAction: 'blacklist', autoOnViolation: false, autoOnBCC: true });
        for (let id = 600; id < 606; id++) {
            h.W.ChatRoomCharacter.push({ MemberNumber: id, WhiteList: [], Reputation: [] });
            h.receive('ChatRoomMessage', bcc(id)); h.flush();
        }
        assert.equal(h.W.Player.BlackList.length, 5);
        assert(!h.W.Player.BlackList.includes(605));
        clock += 60001; h.shield.tick(); h.flush();
        assert.equal(h.W.Player.BlackList.length, 5, 'cooldown alone must not trigger a deferred list action');
        h.receive('ChatRoomMessage', bcc(605)); h.flush();
        assert.equal(h.W.Player.BlackList.length, 6); assert(h.W.Player.BlackList.includes(605));
    } finally { Date.now = realNow; }
});

test('Session enforcement limit stops unbounded automatic changes after fifty members', () => {
    const realNow = Date.now; let clock = 3000000; Date.now = () => clock;
    try {
        const h = fixture({ autoAction: 'blacklist', autoOnViolation: false, autoOnBCC: true });
        for (let offset = 0; offset < 55; offset++) {
            if (offset && offset % 5 === 0) clock += 60001;
            const id = 700 + offset;
            h.W.ChatRoomCharacter.push({ MemberNumber: id, WhiteList: [], Reputation: [] });
            h.receive('ChatRoomMessage', bcc(id)); h.flush();
        }
        assert.equal(h.W.Player.BlackList.length, 50);
        assert.equal(h.calls.length, 50);
        assert(!h.W.Player.BlackList.includes(750));
    } finally { Date.now = realNow; }
});

test('Unversioned generic LSCG-shaped metadata does not establish presence for automatic list actions', () => {
    const h = fixture({ autoAction: 'ghost', autoOnViolation: false, autoOnLSCG: true });
    h.receive('ChatRoomMessage', chat({ Sender: 300, Content: 'LSCGMsg', Type: 'Hidden',
        Dictionary: [{ message: { type: 'sync', settings: { Enabled: true }, reply: false } }] }));
    h.flush(); assert.deepEqual(h.calls, []);
});

test('Malformed optional local relationship data cannot crash automatic-action assessment', () => {
    const h = fixture({ autoAction: 'ghost' }); h.W.Player.Lovership = {};
    assert.doesNotThrow(() => { attack(h); h.flush(); });
});

test('Undo restores a whitelist entry removed by native enforcement when trusted protection was explicitly disabled', () => {
    const h = fixture({ autoAction: 'blacklist', autoOnBCC: true, autoProtectTrusted: false });
    h.W.Player.WhiteList = [300]; h.receive('ChatRoomMessage', bcc(300)); h.flush();
    assert.deepEqual(h.W.Player.BlackList, [300]); assert.deepEqual(h.W.Player.WhiteList, []);
    h.shield.undoAutoAction(actionRow(h).autoActionId); h.flush();
    assert.deepEqual(h.W.Player.BlackList, []); assert.deepEqual(h.W.Player.WhiteList, [300]);
});

test('Undo refuses to reverse a later manual relation change', () => {
    const h = fixture({ autoAction: 'blacklist' }); attack(h); h.flush();
    const row = actionRow(h); h.W.ChatRoomListUpdate(h.W.Player.GhostList, true, 300);
    const before = structuredClone({ black: h.W.Player.BlackList, ghost: h.W.Player.GhostList });
    const calls = h.calls.length;
    assert.equal(h.shield.undoAutoAction(row.autoActionId), false); h.flush();
    assert.equal(h.calls.length, calls); assert.deepEqual(h.W.Player.BlackList, before.black); assert.deepEqual(h.W.Player.GhostList, before.ghost);
});
