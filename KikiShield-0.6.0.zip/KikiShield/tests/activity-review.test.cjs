'use strict';
// Independent regressions from the attribution and retention audit. These run
// entirely offline; native relation mutations use the pinned R132 implementation.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { harness, chat, item } = require('./harness.cjs');
const root = process.env.KIKISHIELD_UPSTREAM || path.resolve(__dirname, '../..');
const LZ = require(path.join(root, 'shield-hardening-audit/LZString.js'));
const effect = String.fromCharCode(1000);
const bcc = (msg, data) => chat({ Content: 'BCC', Type: 'Hidden', Dictionary: { msg, data } });
const control = data => bcc('animaFurtaCommand', data);
const last = h => h.shield.getLog().at(-1);

function fixture(options = {}, make = harness) {
    const h = make(undefined, undefined, false);
    h.W.Player.FriendList = [];
    const source = fs.readFileSync(path.join(root, 'shield-hardening-audit/R132-Screens_Online_ChatRoom_ChatRoom.js'), 'utf8');
    const triggers = source.indexOf('const ChatRoomListOperationTriggers = () => [');
    const update = source.indexOf('function ChatRoomListUpdate(');
    assert(triggers >= 0 && update >= 0);
    h.nativeCalls = [];
    const context = { Player: h.W.Player, Character: h.W.ChatRoomCharacter,
        CommonIsNonNegativeInteger: n => Number.isInteger(n) && n >= 0,
        CharacterRefresh() {}, ServerPlayerRelationsSync() {},
        ServerSend() { throw Error('Unexpected outgoing notification'); } };
    vm.createContext(context);
    vm.runInContext(source.slice(triggers, source.indexOf('\n];', triggers) + 4) + '\n' +
        source.slice(update, source.indexOf('\n/**', update)), context);
    h.W.ChatRoomListUpdate = (...args) => { h.nativeCalls.push(args); return context.ChatRoomListUpdate(...args); };
    h.shield.configure(options);
    return h;
}

function settings(h, spells, role = 0) {
    h.W.LZString = LZ;
    h.W.Player.ExtensionSettings = { BCC: LZ.compressToBase64(JSON.stringify({
        version: '2.2.3', darkMagic: { state: { spells }, limits: { effects: { [effect]: role } } }
    })) };
}

for (const subject of [100, 999]) test(`BCC wardrobe relay subject #${subject} cannot masquerade as another recipient`, () => {
    const h = fixture({ autoAction: 'blacklist' });
    h.W.Player.AllowedInteractions = 0;
    h.receive('ChatRoomMessage', control({ name: 'changeAppearance', target: subject, appearance: [] }));
    assert.equal(last(h).severity, 'serious');
    assert.equal(last(h).target, 100);
    assert.equal(JSON.parse(last(h).detail).Dictionary.data.target, subject);
    h.flush();
    assert(h.W.Player.BlackList.includes(300));
    assert(!h.W.Player.BlackList.includes(subject));
});

for (const name of ['toggleKneel', 'sendMessage', 'mapMove']) test(`Real BCC settings identify a noncaster's ${name} command independently of isolation`, () => {
    const h = fixture({ autoAction: 'blacklist' });
    h.W.Player.AllowedInteractions = 0;
    settings(h, [{ name: 'Known active spell', effects: effect, castedBy: { id: 200 } }]);
    h.receive('ChatRoomMessage', control({ name, message: 'Synthetic', pos: { x: 1, y: 2 } }));
    assert.equal(last(h).severity, 'serious');
    h.flush(); assert(h.W.Player.BlackList.includes(300));
});

test('Unreadable BCC state is uncertain evidence and does not alone autoblock a controller', () => {
    const h = fixture({ autoAction: 'blacklist' });
    h.W.Player.AllowedInteractions = 0;
    h.W.LZString = LZ;
    h.W.Player.ExtensionSettings = { BCC: 'invalid' };
    h.receive('ChatRoomMessage', control({ name: 'toggleKneel' }));
    assert.equal(last(h).severity, 'caution');
    h.flush(); assert.equal(h.nativeCalls.length, 0);
});

test('The actual permitted caster is not autoblocked just because BCC isolation is enabled', () => {
    const h = fixture({ autoAction: 'blacklist' });
    h.W.Player.AllowedInteractions = 0;
    settings(h, [{ name: 'Known active spell', effects: effect, castedBy: { id: 300 } }]);
    h.receive('ChatRoomMessage', control({ name: 'toggleKneel' }));
    assert.equal(last(h).severity, 'caution');
    h.flush(); assert.equal(h.nativeCalls.length, 0);
});

test('Current recipient role can revoke a known caster despite open native item permissions', () => {
    const h = fixture({ autoAction: 'blacklist' });
    h.W.Player.AllowedInteractions = 0;
    settings(h, [{ name: 'Known active spell', effects: effect, castedBy: { id: 300 } }], 3);
    h.receive('ChatRoomMessage', control({ name: 'toggleKneel' }));
    assert.equal(last(h).severity, 'serious');
    h.flush(); assert(h.W.Player.BlackList.includes(300));
});

const targetCases = [
    ['BCC', value => ['ChatRoomMessage', control({ name: 'toggleKneel', target: value })]],
    ['LSCG', value => ['ChatRoomMessage', chat({ Type: 'Hidden', Content: 'LSCGMsg', Dictionary: [{ message: {
        type: 'command', target: value, command: { name: 'spell', args: [] } } }] })]],
    ['item', value => ['ChatRoomSyncItem', { Source: 300, Item: { Target: value, Group: 'Test', Name: 'New' } }]],
    ['character', value => ['ChatRoomSyncSingle', { SourceMemberNumber: 300, Character: { MemberNumber: value } }]],
    ['game', value => ['ChatRoomGameResponse', { Sender: 300, Data: { Target: value } }]]
];
for (const [name, packet] of targetCases) test(`${name}: malformed target cannot retain an oversized payload outside the detail limit`, () => {
    const h = fixture();
    const target = { reviewMarker: 'z'.repeat(1048577) };
    h.receive(...packet(target));
    const row = last(h);
    assert(row);
    assert.equal(row.detail, null);
    assert.notEqual(row.target, target);
    assert(['string', 'number'].includes(typeof row.target));
    assert(JSON.stringify(row).length < 4096);
});

test('Oversized primitive target labels stay bounded independently of omitted details', () => {
    const h = fixture();
    h.receive(...targetCases[1][1]('q'.repeat(1048577)));
    assert.equal(last(h).detail, null);
    assert.equal(typeof last(h).target, 'string');
    assert(last(h).target.length <= 200);
});

// Track actual Maps allocated by the addon without changing its source or
// exposing test-only production APIs. This catches private row retention that
// a getLog() assertion would miss after clearing or evicting Activity.
function trackedHarness() {
    const maps = [];
    class TrackedMap extends Map { constructor(...args) { super(...args); maps.push(this); } }
    const addonBox = { exports: {} };
    vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../KikiShield.user.js'), 'utf8'), {
        module: addonBox, Map: TrackedMap
    });
    const harnessBox = { exports: {} };
    vm.runInNewContext(fs.readFileSync(path.join(__dirname, 'harness.cjs'), 'utf8'), {
        module: harnessBox, structuredClone,
        require(name) { assert.equal(name, '../KikiShield.user.js'); return addonBox.exports; }
    });
    return { make: harnessBox.exports.harness, maps };
}
function retainedMapText(maps) { return JSON.stringify(maps.map(map => [...map.entries()])); }

test('Queued actions and undo history retain no private payload, including after Clear Activity', () => {
    const tracked = trackedHarness(), h = fixture({ autoAction: 'blacklist' }, tracked.make);
    const marker = 'PRIVATE_REVIEW_COMMAND_78621';
    h.receive('ChatRoomMessage', control({ name: 'publishAction', params: { Content: marker, Type: 'Action' } }));
    assert(last(h).detail.includes(marker));
    assert(!retainedMapText(tracked.maps).includes(marker));
    h.flush(); assert(last(h).autoActionId !== null);
    assert(!retainedMapText(tracked.maps).includes(marker));
    h.shield.clearLog();
    assert.equal(h.shield.getLog().length, 0);
    assert(!retainedMapText(tracked.maps).includes(marker));
});

test('Clearing Activity cancels pending enforcement so the removed evidence cannot apply a later ban', () => {
    const h = fixture({ autoAction: 'blacklist' });
    h.receive('ChatRoomMessage', control({ name: 'publishAction', params: { Content: 'Synthetic', Type: 'Action' } }));
    h.shield.clearLog(); h.flush();
    assert.equal(h.nativeCalls.length, 0);
    assert.equal(h.shield.getLog().length, 0);
});

test('Evicted automatic-action rows are not retained by undo history', () => {
    const tracked = trackedHarness(), h = fixture({ autoAction: 'blacklist' }, tracked.make);
    const marker = 'PRIVATE_EVICTION_COMMAND_29853';
    h.receive('ChatRoomMessage', control({ name: 'publishAction', params: { Content: marker, Type: 'Action' } }));
    h.flush();
    for (let i = 0; i < 101; i++) h.receive('ChatRoomMessage', bcc('unrecognized_' + i, { i }));
    assert(!JSON.stringify(h.shield.getLog()).includes(marker));
    assert(!retainedMapText(tracked.maps).includes(marker));
});

test('A malformed local lover list cannot interrupt ingress and skips enforcement while trust is unknown', () => {
    const h = fixture({ autoAction: 'blacklist' });
    h.W.Player.Lovership = {};
    assert.doesNotThrow(() => h.receive('ChatRoomSyncItem', item()));
    assert.match(last(h).autoAction, /not ready|skipped/i);
    assert.doesNotThrow(() => h.flush());
    assert.equal(h.nativeCalls.length, 0);
});

test('Unknown BCC and hidden commands retain inspectable evidence without accusing the sender', () => {
    const h = fixture({ autoAction: 'blacklist' });
    for (const packet of [bcc('newUnknownCommand', { instruction: 'review only' }),
        chat({ Type: 'Hidden', Content: 'BCXMsg', Dictionary: { type: 'query', message: { query: 'unknown-write' } } })]) {
        h.receive('ChatRoomMessage', packet);
        assert.equal(last(h).severity, 'caution');
        assert.deepEqual(JSON.parse(last(h).detail), packet);
    }
    h.flush(); assert.equal(h.nativeCalls.length, 0);
});

test('BCC request beep is inspectable but never serious solely because it is an addon request', () => {
    const h = fixture({ autoAction: 'blacklist' });
    const packet = { MemberNumber: 300, BeepType: 'Leash', Message: { type: 'BCC_request', data: { instruction: 'review only' } } };
    h.receive('AccountBeep', packet);
    assert.equal(last(h).severity, 'caution');
    assert.deepEqual(JSON.parse(last(h).detail), packet);
    h.flush(); assert.equal(h.nativeCalls.length, 0);
});
