"use strict";
const test = require("node:test"), assert = require("node:assert/strict");
const path = require("node:path");
const sourceRoot = process.env.KIKISHIELD_UPSTREAM || path.resolve(__dirname, "../..");
const LZ = require(path.join(sourceRoot, "shield-hardening-audit/LZString.js"));
const V = require("../KikiShield.user.js")({}).validationForTests;
const { harness, chat } = require("./harness.cjs");
const effect = n => String.fromCharCode(n);
const spell = (code = 1000, data) => ({ name: "Offline spell", icon: "BeamsAura", effects: effect(code),
    createdBy: { name: "Offline", id: 200 }, ...(data ? { data: { [effect(code)]: data } } : {}) });
const outfit = value => LZ.compressToBase64(JSON.stringify(value));

test("bounded decoder agrees with BC LZString on ASCII, UTF16 and patterns", () => {
    let seed = 624123;
    const samples = ["", "a", "[]", "{}", "a".repeat(10000), "Привет 🛡️", "abc123".repeat(1500)];
    for (let i = 0; i < 100; i++) {
        let s = "";
        for (let n = 0; n < i * 5; n++) { seed = (seed * 1664525 + 1013904223) >>> 0; s += String.fromCharCode(seed % 65536); }
        samples.push(s);
    }
    for (const sample of samples) assert.equal(V.decodeBase64(LZ.compressToBase64(sample)), sample);
});
test("decoder caps output during expansion and handles exact output limit", () => {
    for (const s of ["a", "abcdef", "A".repeat(10000), "abcd".repeat(500)]) {
        const encoded = LZ.compressToBase64(s);
        assert.equal(V.decodeBase64(encoded, s.length), s);
        assert.equal(V.decodeBase64(encoded, s.length - 1), null);
    }
    assert.equal(V.decodeBase64(LZ.compressToBase64("A".repeat(300000))), null);
});
test("malformed / truncated / invalid input is rejected without throwing", () => {
    for (const value of [undefined, null, 1, {}, "", "!", "=", "A===", "zz", "🛡", "a".repeat(8193)])
        assert.equal(V.decodeBase64(value), null);
    const encoded = LZ.compressToBase64("The complete outfit JSON is required.");
    assert.equal(V.decodeBase64(encoded.slice(0, Math.floor(encoded.length / 2))), null);
});
test("all audited no-argument effects accept ordinary legitimate spell payloads", () => {
    for (const code of [1000, 1002, 1003, 1004, 1006, 1008, 1010, 1011]) assert.equal(V.validSpell(spell(code)), true);
});
test("Masquerada accepts bounded appearance bundles and rejects decoded malformed data", () => {
    const valid = outfit([{ Name: "Item", Group: "ItemArms", Color: ["Default"], Property: { TypeRecord: { a: 1 } } }]);
    assert.equal(V.validSpell(spell(1001, { outfit: valid })), true);
    assert.equal(V.validOutfit(outfit([])), true);
    for (const value of [null, "invalid", outfit(null), outfit({ Name: "Item" }), outfit([null]), outfit([{ Name: "Item" }]),
        outfit([{ Name: "Item", Group: "ItemArms", Property: [] }]),
        LZ.compressToBase64('[{"Name":"Item","Group":"ItemArms","__proto__":{"polluted":true}}]')])
        assert.equal(V.validSpell(spell(1001, { outfit: value })), false);
});
test("Spatium and speech parameters match native defaults and known enum values", () => {
    assert.equal(V.validSpell(spell(1005, { roomName: "Offline room" })), true);
    assert.equal(V.validSpell(spell(1005, { roomName: "Offline room", lobby: "classic", isPrivate: true })), true);
    for (const data of [{}, { roomName: {} }, { roomName: " " }, { roomName: "Room", lobby: "other" }, { roomName: "Room", isPrivate: "yes" }])
        assert.equal(V.validSpell(spell(1005, data)), false);
    for (const speechType of [undefined, "puppy", "kitty", "bunny", "baby", "cow"])
        assert.equal(V.validSpell(spell(1007, { speechType })), true);
    assert.equal(V.validSpell(spell(1007, { speechType: {} })), false);
});
test("Traditio validates safe editable templates, known effects and nested sharing depth", () => {
    assert.equal(V.validSpell(spell(1009, { spell: spell(1001) })), true); // Outfit supplied later at cast time.
    assert.equal(V.validSpell(spell(1009, { spell: spell(1005) })), true); // Room supplied later.
    assert.equal(V.validSpell(spell(1009, { spell: spell(1009) })), true); // Gift chosen later.
    assert.equal(V.validSpell(spell(1009, { spell: spell(1009, { spell: spell(1000) }) })), true);
    assert.equal(V.validSpell(spell(1009, { spell: spell(1009, { spell: spell(1009, { spell: spell(1000) }) }) })), false);
    for (const nested of [null, {}, { ...spell(), icon: "unknown" }, { ...spell(), effects: effect(999) },
        { ...spell(), createdBy: null }, spell(1001, { outfit: "invalid" })])
        assert.equal(V.validSpell(spell(1009, { spell: nested })), false);
});
test("invalid containers, cycles, names and unexpected effect ids are rejected", () => {
    const cyclic = spell(); cyclic.data = { cycle: cyclic };
    for (const invalid of [null, [], {}, cyclic, { ...spell(), name: " " }, { ...spell(), effects: effect(1012) },
        { ...spell(), effects: effect(1000) + effect(1000) },
        { ...spell(), data: [] }, { ...spell(), data: { [effect(1000)]: "bad" } },
        { ...spell(), createdBy: { name: "Offline", id: Infinity } }]) assert.equal(V.validSpell(invalid), false);
});

test("recipient ingress rejects corrupt outfits before every listener, while a valid permitted outfit passes", () => {
    const h = harness();
    h.W.LZString = LZ;
    h.W.Player.ExtensionSettings = { BCC: LZ.compressToBase64(JSON.stringify({ darkMagic: { limits: { effects: { [effect(1001)]: 0 } } } })) };
    let seen = 0; h.socket.onAny(() => seen++);
    const send = value => h.receive("ChatRoomMessage", chat({ Sender: 200, Type: "Hidden", Content: "BCC", Dictionary: { msg: "castSpell", data: { spell: spell(1001, { outfit: value }) } } }));
    send("malformed"); send(outfit(null)); send(LZ.compressToBase64("A".repeat(300000)));
    assert.equal(seen, 0);
    send(outfit([{ Name: "Item", Group: "ItemArms" }])); assert.equal(seen, 1);
    h.W.Player.GhostList = [200]; send(outfit([])); assert.equal(seen, 1);
});

test("BCC custom activity isolation does not misidentify ordinary BC activities or ordinary text", () => {
    const h = harness(undefined, undefined, false);
    for (const name of ["BCC_StealPanties", "BCC_SuckOnTipOfHair"]) {
        assert.equal(h.shield.filter(["ChatRoomMessage", chat({ Sender: 200, Type: "Activity", Content: "ChatOther-ItemMouth-" + name, Dictionary: [{ TargetCharacter: 100 }] })]), null);
        assert.equal(h.shield.filter(["ChatRoomMessage", chat({ Sender: 200, Type: "Activity", Content: "Synthetic", Dictionary: [{ ActivityName: name }] })]), null);
        assert(h.shield.filter(["ChatRoomMessage", chat({ Sender: 200, Type: "Chat", Content: name })]));
    }
    assert(h.shield.filter(["ChatRoomMessage", chat({ Sender: 200, Type: "Activity", Content: "ChatOther-ItemArms-Touch", Dictionary: [{ TargetCharacter: 100 }] })]));
});
