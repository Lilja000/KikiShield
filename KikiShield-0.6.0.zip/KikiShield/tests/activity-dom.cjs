'use strict';
// Node DOM simulation only: no browser or real account/network. Optional linkedom dependency.
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const {parseHTML} = process.env.KIKISHIELD_DOM_MODULES
    ? require(path.join(process.env.KIKISHIELD_DOM_MODULES, 'linkedom')) : require('linkedom');
const createShield = require('../KikiShield.user.js');
const {TestSocket} = require('./harness.cjs');

function fixture() {
    const {window} = parseHTML('<!doctype html><html><body><main>Offline fixture</main></body></html>');
    // linkedom has no layout engine or select.value setter; mirror the standard DOM APIs.
    Object.defineProperty(window.HTMLSelectElement.prototype, 'value', {
        configurable: true,
        get() {return this.querySelector('option[selected]')?.value ?? this.querySelector('option')?.value ?? '';},
        set(value) {for (const option of this.querySelectorAll('option')) option.toggleAttribute('selected', option.value === String(value));}
    });
    window.HTMLElement.prototype.getBoundingClientRect = function () {
        const width = this.id === 'badge' ? 46 : 366, height = this.id === 'badge' ? 46 : 600;
        return {left:12,top:12,right:12+width,bottom:12+height,width,height,x:12,y:12};
    };
    Object.defineProperty(window.HTMLElement.prototype,'offsetWidth',{configurable:true,get(){return this.id==='badge'?46:366;}});
    Object.defineProperty(window.HTMLElement.prototype,'offsetHeight',{configurable:true,get(){return this.id==='badge'?46:600;}});
    const callbacks=new Map(), saved=new Map();let next=1;
    const W={document:window.document,innerWidth:390,innerHeight:844,addEventListener(){},URL:{createObjectURL(){return 'blob:local';},revokeObjectURL(){}},Blob,
        Player:{MemberNumber:100,CharacterID:'offline',AllowedInteractions:3,WhiteList:[200],BlackList:[],GhostList:[],FriendList:[],Ownership:null,Lovership:[],Appearance:[{Name:'Accepted',Group:'Test'}],ActivePose:[]},
        ChatRoomCharacter:[{MemberNumber:200},{MemberNumber:300},{MemberNumber:301}],ChatRoomData:{ID:'offline',Name:'Offline',Character:[]},ChatRoomAllowCharacterUpdate:true,
        ServerSocket:null,ServerAppearanceBundle:a=>structuredClone(a),ChatRoomCharacterUpdate(){},
        localStorage:{getItem:k=>saved.get(k),setItem:(k,v)=>saved.set(k,v)},
        setInterval:()=>999,clearInterval(){},setTimeout:fn=>{callbacks.set(next,fn);return next++;},clearTimeout:id=>callbacks.delete(id)};
    W.ChatRoomListUpdate=(list,add,id)=>{
        const modify=(arr,add)=>{const index=arr.indexOf(id);if(add&&index<0)arr.push(id);else if(!add&&index>=0)arr.splice(index,1);};
        modify(list,add);if(list===W.Player.GhostList)modify(W.Player.BlackList,add);
        if(add&&(list===W.Player.GhostList||list===W.Player.BlackList))modify(W.Player.WhiteList,false);
    };
    const shield=createShield(W).start();W.ServerSocket=new TestSocket();W.ServerSocket.connected=true;shield.tick();
    const shadow=W.document.getElementById('kikishield-root').shadowRoot,el=id=>shadow.getElementById(id);
    el('badge').onclick({detail:0});
    return {W,shield,shadow,el,
        receive(event,data){W.ServerSocket.onevent({data:[event,data]});shield.tick();},
        flush(){const pending=[...callbacks.values()];callbacks.clear();for(const fn of pending)fn();shield.tick();},
        change(id,value){el(id).value=String(value);el(id).onchange();},
        exceptions(value){el('auto-exceptions').value=value;el('auto-exceptions').oninput();el('auto-exceptions-save').onclick();},
        activity(){el('tab-activity').onclick();}};
}
const command=(sender=300,extra={})=>({Sender:sender,Type:'Hidden',Content:'BCC',Dictionary:{msg:'animaFurtaCommand',data:{name:'changeAppearance',target:100,payload:'<img src=x onerror="window.fixtureXss=true">',...extra}}});

test('automatic-action UI defaults and strict member exception edits',()=>{
    const f=fixture();
    assert.equal(f.el('auto-action').value,'off');
    assert.equal(f.el('auto-bcc').checked,false);assert.equal(f.el('auto-lscg').checked,false);assert.equal(f.el('auto-trusted').checked,true);
    f.exceptions('200, 301');assert.deepEqual(f.shield.status().options.autoExceptions,[200,301]);
    for(const invalid of ['200, nope, 301','200,','+200','200;301','9007199254740992','1,,2']) {
        f.exceptions(invalid);assert.equal(f.el('auto-exceptions').getAttribute('aria-invalid'),'true');
        assert.deepEqual(f.shield.status().options.autoExceptions,[200,301]);assert.equal(f.el('auto-exceptions').value,invalid);
        f.shield.tick();assert.equal(f.el('auto-exceptions').value,invalid,'background render preserves invalid draft');
    }
    f.exceptions('301, 301, 200');assert.equal(f.el('auto-exceptions').value,'301, 200');
    f.exceptions('');assert.deepEqual(f.shield.status().options.autoExceptions,[]);
    f.change('auto-threshold','3');assert.equal(f.shield.status().options.autoThreshold,3);
    f.el('auto-violation').checked=false;f.el('auto-violation').onchange();assert.equal(f.el('auto-threshold').disabled,true);
});

test('activity command arguments are inert text and detail expansion survives updates and filters',()=>{
    const f=fixture();f.activity();f.receive('ChatRoomMessage',command());
    const initial=f.el('events').querySelector('li'),id=initial.dataset.eventId;
    assert.match(initial.querySelector('pre').textContent,/<img src=x onerror=/);assert.equal(initial.querySelector('.event-detail img'),null);
    const card=initial.querySelector('details');card.open=true;initial.querySelector('pre').scrollTop=51;
    f.receive('ChatRoomSyncItem',{Source:301,Item:{Target:100,Group:'Test',Name:'Blocked'}});
    const retained=[...f.el('events').children].find(node=>node.dataset.eventId===id);
    assert.equal(retained.querySelector('details').open,true);assert.equal(retained.querySelector('pre').scrollTop,51);
    for(const severity of ['serious','caution','background','system','all']) {
        f.change('severity-filter',severity);const logs=f.shield.getLog(),visible=logs.filter(x=>severity==='all'||x.severity===severity);
        assert.equal(f.el('events').children.length,visible.length);assert.equal(f.el('event-count').textContent,visible.length+' of '+logs.length);
        assert.equal(f.el('empty').hidden,visible.length>0);
        if(!visible.length)assert.equal(f.el('empty-title').textContent,'No matching events');
    }
    assert.equal([...f.el('events').children].find(node=>node.dataset.eventId===id).querySelector('details').open,true);
    assert.match(f.el('events').textContent,/Serious/);
    f.el('clear').onclick();assert.equal(f.shield.getLog().length,0);assert.equal(f.el('events').children.length,0);
    assert.equal(f.el('empty-title').textContent,'No events yet');assert.equal(f.el('export').disabled,true);
});

test('automatic blacklist / ghost status and Undo use actual core operations',()=>{
    for(const action of ['blacklist','ghost']) {
        const f=fixture();f.change('auto-action',action);f.activity();f.receive('ChatRoomMessage',command());f.flush();
        assert(f.W.Player.BlackList.includes(300));
        assert.equal(f.W.Player.GhostList.includes(300),action==='ghost');
        const row=f.shield.getLog().find(x=>x.autoActionId);assert(row);
        const node=[...f.el('events').children].find(x=>x.dataset.eventId===String(row.id));
        node.querySelector('details').open=true;assert.match(node.textContent,action==='ghost'?/Added to ghostlist and blacklist/:/Added to blacklist/);
        node.querySelector('.undo-action').onclick();assert(!f.W.Player.BlackList.includes(300));assert(!f.W.Player.GhostList.includes(300));
        const updated=[...f.el('events').children].find(x=>x.dataset.eventId===String(row.id));
        assert.equal(updated.querySelector('.undo-action'),null);assert.match(updated.textContent,/Automatic list change undone/);
    }
});

test('numeric zero targets remain visible in expanded details',()=>{
    const f=fixture();f.shield.configure({blockLSCG:true});f.activity();f.receive('ChatRoomMessage',{Sender:300,Type:'Hidden',Content:'LSCGMsg',Dictionary:[{message:JSON.stringify({type:'command',target:0,command:{name:'debug',args:[]}})}]});
    const facts=[...f.el('events').querySelectorAll('dt')];const target=facts.find(x=>x.textContent==='Target');
    assert(target);assert.equal(target.nextElementSibling.textContent,'0');
});
