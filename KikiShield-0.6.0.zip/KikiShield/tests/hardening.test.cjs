'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { harness, chat, item } = require('./harness.cjs');
const effect = String.fromCharCode(1000), friendlyEffect = String.fromCharCode(1002);
function localBCC(h, settings) {
    h.W.LZString = { decompressFromBase64: s => s };
    h.W.Player.ExtensionSettings = { BCC: JSON.stringify({ version: '2.2.3', ...settings }) };
}
const bcc = (id, msg, data) => chat({ Sender: id, Type: 'Hidden', Content: 'BCC', Dictionary: { msg, data } });
const lscg = (id, name = 'spell', changes = {}) => chat({ Sender: id, Type: 'Hidden', Content: 'LSCGMsg', Dictionary: [{ message: { type: 'command', target: 100, command: { name, args: [] }, ...changes } }] });
const spell = effects => ({ spell: { name: 'Fixture', icon: 'BeamsAura', effects, data: {}, createdBy: { name: 'Fixture', id: 200 } } });
const accepted = (h, event, data) => h.shield.filter([event, data]) !== null;

for (const content of ['BCC', 'LSCGMsg']) test(`${content}: metadata passes in compatibility mode; selected isolation and block lists win`, () => {
    const h = harness(); h.W.Player.AllowedInteractions = 5;
    const data = content === 'BCC' ? bcc(300, 'syncStorage', { storage: { version: '2.2.3' } })
        : chat({ Content: content, Type: 'Hidden', Dictionary: [{ message: { type: 'sync', settings: { Enabled: true }, reply: false } }] });
    assert(accepted(h, 'ChatRoomMessage', data));
    h.shield.configure({ interactionMode: 'none', isolateAddons: true });
    assert(!accepted(h, 'ChatRoomMessage', data));
    h.W.Player.GhostList = [300]; assert(!accepted(h, 'ChatRoomMessage', data));
});

for (const type of ['Hidden', 'Chat', 'Activity', 'Action']) test(`BCC role bypass blocked even with message Type ${type}`, () => {
    const h = harness(); h.W.Player.AllowedInteractions = 0;
    localBCC(h, { darkMagic: { limits: { effects: { [friendlyEffect]: 2 } } } });
    const data = { ...bcc(300, 'castSpell', spell(friendlyEffect)), Type: type };
    assert(!accepted(h, 'ChatRoomMessage', data)); // sender.WhiteList already contains us
    h.W.Player.WhiteList.push(300); assert(accepted(h, 'ChatRoomMessage', data));
});

for (const role of [0, 1, 2, 3, 4]) test(`BCC effect role ${role} uses recipient relation; revocation takes effect`, () => {
    const h = harness(); h.W.Player.AllowedInteractions = 0;
    h.W.ChatRoomCharacter[1].FriendList = [100]; h.W.ChatRoomCharacter[1].WhiteList = [100];
    localBCC(h, { darkMagic: { limits: { effects: { [effect]: role } } } });
    const data = bcc(300, 'castSpell', spell(effect));
    assert.equal(accepted(h, 'ChatRoomMessage', data), role === 0);
    if (role === 1) h.W.Player.FriendList = [300];
    if (role === 2) h.W.Player.WhiteList.push(300);
    if (role === 3) h.W.Player.Lovership = [{ MemberNumber: 300 }];
    if (role === 4) h.W.Player.Ownership = { MemberNumber: 300 };
    assert(accepted(h, 'ChatRoomMessage', data));
    h.W.Player.BlackList = [300]; assert(!accepted(h, 'ChatRoomMessage', data));
});

test('Friend role does not override native OwnerOnly; unknown and corrupt own BCC state fail closed', () => {
    const h = harness(); const data = bcc(200, 'castSpell', spell(friendlyEffect));
    assert(!accepted(h, 'ChatRoomMessage', data));
    localBCC(h, {}); h.W.Player.FriendList = [200]; assert(accepted(h, 'ChatRoomMessage', data));
    h.W.Player.AllowedInteractions = 5; assert(!accepted(h, 'ChatRoomMessage', data));
    h.W.Player.Ownership = { MemberNumber: 200 }; assert(accepted(h, 'ChatRoomMessage', data));
    h.W.Player.ExtensionSettings.BCC = '{broken'; assert(!accepted(h, 'ChatRoomMessage', data));
});

test('BCC default NOX role requires our lover and all effects must pass', () => {
    const h = harness(); h.W.Player.FriendList = [200]; localBCC(h, {});
    const data = bcc(200, 'castSpell', spell(effect + friendlyEffect));
    assert(!accepted(h, 'ChatRoomMessage', data));
    h.W.Player.Lovership = [{ MemberNumber: 200 }]; assert(accepted(h, 'ChatRoomMessage', data));
    h.W.Player.FriendList = []; assert(!accepted(h, 'ChatRoomMessage', data));
});

test('Active AnimaFurta binds commands to latest caster and current recipient role', () => {
    const h = harness(); h.W.Player.WhiteList.push(300);
    localBCC(h, { darkMagic: { limits: { effects: { [effect]: 2 } }, state: { spells: [
        { effects: effect, castedBy: { id: 300 } }, { effects: effect, castedBy: { id: 200 } }
    ] } } });
    for (const name of ['toggleKneel', 'sendMessage', 'mapMove']) {
        const data = { name, message: 'Fixture', pos: { x: 2, y: 3 } };
        assert(accepted(h, 'ChatRoomMessage', bcc(200, 'animaFurtaCommand', data)));
        assert(!accepted(h, 'ChatRoomMessage', bcc(300, 'animaFurtaCommand', data)));
    }
    h.W.Player.WhiteList = []; assert(!accepted(h, 'ChatRoomMessage', bcc(200, 'animaFurtaCommand', { name: 'toggleKneel' })));
});

test('Even the real caster cannot relay wardrobe changes or arbitrary packets as us', () => {
    const h = harness();
    localBCC(h, { darkMagic: { limits: { effects: { [effect]: 0 } }, state: { spells: [{ effects: effect, castedBy: { id: 200 } }] } } });
    for (const target of [100, 300]) assert(!accepted(h, 'ChatRoomMessage', bcc(200, 'animaFurtaCommand', { name: 'changeAppearance', target, appearance: [] })));
    assert(!accepted(h, 'ChatRoomMessage', bcc(200, 'animaFurtaCommand', { name: 'publishAction', params: { Type: 'Hidden' } })));
    assert(accepted(h, 'ChatRoomSyncItem', item(200))); // ordinary authorized wardrobe path survives
});

for (const type of ['command', 'broadcast']) test(`LSCG ${type}: positive/negative authorization and foreign target rejection`, () => {
    const h = harness();
    assert(accepted(h, 'ChatRoomMessage', lscg(200, 'spell', { type })));
    assert(!accepted(h, 'ChatRoomMessage', lscg(300, 'spell', { type })));
    assert(!accepted(h, 'ChatRoomMessage', lscg(200, 'spell', { type, target: 400 })));
    if (type === 'broadcast') assert(accepted(h, 'ChatRoomMessage', lscg(200, 'spell', { type, target: null })));
});

test('LSCG metadata cannot smuggle a command into old Chaos Aura', () => {
    const h = harness();
    for (const type of ['init', 'sync']) assert(!accepted(h, 'ChatRoomMessage', lscg(200, 'spell', { type })));
    assert(!accepted(h, 'ChatRoomMessage', lscg(200, 'debug')));
});

test('LSCG beeps: allowed sender passes; ghost, wrong target and malformed args stop', () => {
    const h = harness(); const msg = { IsLSCG: true, ...lscg(200).Dictionary[0].message };
    for (const Message of [msg, JSON.stringify(msg)]) assert(accepted(h, 'AccountBeep', { MemberNumber: 200, BeepType: 'Leash', Message }));
    h.W.Player.GhostList = [200]; assert(!accepted(h, 'AccountBeep', { MemberNumber: 200, BeepType: 'Leash', Message: msg }));
    h.W.Player.GhostList = [];
    msg.command.args = [null]; assert(!accepted(h, 'AccountBeep', { MemberNumber: 200, BeepType: 'Leash', Message: msg }));
});

test('KikiLink communication remains usable in OwnerOnly and Block interactions modes', () => {
    const h = harness(); h.W.Player.AllowedInteractions = 5; h.shield.configure({ interactionMode: 'none' });
    const content = 'KIKILINK/1 ' + JSON.stringify({ t: 'pq', id: 'fixture' });
    const room = chat({ Content: content, Type: 'Hidden' }), beep = { MemberNumber: 300, BeepType: 'KikiLink', Message: content };
    assert(accepted(h, 'ChatRoomMessage', room)); assert(accepted(h, 'AccountBeep', beep));
    h.W.Player.GhostList = [300]; assert(!accepted(h, 'ChatRoomMessage', room)); assert(!accepted(h, 'AccountBeep', beep));
    h.W.Player.GhostList = []; h.shield.configure({ blockOtherHidden: true }); assert(!accepted(h, 'ChatRoomMessage', room));
});

test('BCX metadata and read queries pass, edits and command triggers require interaction permission', () => {
    const h = harness(); h.W.Player.AllowedInteractions = 5;
    const msg = Dictionary => chat({ Content: 'BCXMsg', Type: 'Hidden', Dictionary });
    for (const type of ['hello', 'goodbye', 'somethingChanged', 'queryAnswer', 'ChatRoomStatusEvent']) assert(accepted(h, 'ChatRoomMessage', msg({ type, message: {} })));
    for (const query of ['permissions', 'rolesData', 'conditionsGet']) assert(accepted(h, 'ChatRoomMessage', msg({ type: 'query', message: { query } })));
    for (const query of ['editRole', 'commandTrigger', 'curseItem', 'relationshipsSet']) assert(!accepted(h, 'ChatRoomMessage', msg({ type: 'query', message: { query } })));
    h.W.Player.Ownership = { MemberNumber: 300 }; assert(accepted(h, 'ChatRoomMessage', msg({ type: 'query', message: { query: 'curseItem' } })));
});

test('Bounded shape checks reject nested prototype keys, cycles and giant payloads without throwing', () => {
    const h = harness(); const bad = JSON.parse('{"version":"2.2.3","x":{"__proto__":{"evil":true}}}');
    assert(!accepted(h, 'ChatRoomMessage', bcc(200, 'syncStorage', { storage: bad })));
    const cycle = { version: '2.2.3' }; cycle.self = cycle;
    assert(!accepted(h, 'ChatRoomMessage', bcc(200, 'syncStorage', { storage: cycle })));
    assert(!accepted(h, 'ChatRoomMessage', bcc(200, 'syncStorage', { storage: { version: '2.2.3', text: 'x'.repeat(1048577) } })));
    assert.equal({}.evil, undefined);
});

test('Empty valid appearance can be preserved; CharacterID alias is protected', () => {
    const h = harness(); h.W.Player.Appearance = [];
    const data = { SourceMemberNumber: 300, Character: { ID: 'own', MemberNumber: 999, Appearance: [{ Name: 'Changed' }] } };
    const result = h.shield.filter(['ChatRoomSyncCharacter', data]);
    assert(result); assert.deepEqual(result[1].Character.Appearance, []);
    assert.notEqual(h.shield.status().fault, 'error');
});

test('Repeated cooperative socket wrappers do not apply snapshot preservation twice', () => {
    const h = harness(); let deliveries = 0; h.socket.onAny(() => deliveries++);
    for (let i = 0; i < 8; i++) {
        const prev = h.socket.emitEvent;
        h.socket.emitEvent = function(args) { return prev.call(this, args); };
        h.shield.tick();
    }
    const before = h.shield.status().snapshots;
    h.receive('ChatRoomSync', { Character: [{ MemberNumber: 100, Appearance: [] }] });
    assert.equal(h.shield.status().snapshots, before + 1); assert.equal(deliveries, 1);
    h.receive('ChatRoomSyncItem', item(300)); assert.equal(deliveries, 1);
});

test('Game action envelope: native round progression, cards and other targets remain usable', () => {
    const h = harness(); h.W.ChatRoomData.Game = 'MagicBattle';
    const data = Data => ({ Sender: 300, Data, RNG: 0.5 });
    assert(!accepted(h, 'ChatRoomGameResponse', data({ GameProgress: 'Action', Target: 100 })));
    assert(accepted(h, 'ChatRoomGameResponse', data({ GameProgress: 'Action', Target: 200 })));
    assert(accepted(h, 'ChatRoomGameResponse', data({ GameProgress: 'Next' })));
    h.W.ChatRoomData.Game = 'ClubCard'; assert(accepted(h, 'ChatRoomGameResponse', data({ GameProgress: 'Action' })));
    h.W.Player.BlackList = [300]; assert(!accepted(h, 'ChatRoomGameResponse', data({ GameProgress: 'Action' })));
});

test('Optional addon isolation blocks both commands and synchronization', () => {
    const h = harness(); assert(accepted(h, 'ChatRoomMessage', lscg(200)));
    h.shield.configure({ isolateAddons: true }); assert(!accepted(h, 'ChatRoomMessage', lscg(200)));
    assert(!accepted(h, 'ChatRoomMessage', bcc(200, 'syncStorage', { storage: { version: '2.2.3' } })));
});

// Deterministic malformed-wire fuzz, checking every protected route for uncaught exceptions.
test('Malformed-wire regression: 1800 bounded packets never escape the ingress filter', () => {
    const h = harness(), values = [undefined, null, true, false, 0, -1, 1.5, 'text', [], {}, { constructor: {} }, [null], 'x'.repeat(2048)];
    for (let i = 0; i < 1800; i++) {
        const v = values[i % values.length];
        const packet = i % 6 === 0 ? ['ChatRoomMessage', chat({ Content: 'BCC', Dictionary: v })]
            : i % 6 === 1 ? ['ChatRoomMessage', lscg(200, 'spell', { command: v })]
            : i % 6 === 2 ? ['AccountBeep', { MemberNumber: 200, BeepType: 'Leash', Message: v }]
            : i % 6 === 3 ? ['ChatRoomSyncItem', { Source: 200, Item: v }]
            : i % 6 === 4 ? ['ChatRoomSyncCharacter', { SourceMemberNumber: 200, Character: v }]
            : ['ChatRoomGameResponse', { Sender: 200, Data: v }];
        assert.doesNotThrow(() => h.shield.filter(packet));
    }
});

test('BCC metadata cannot forge our controller identity; an observed local cast grants only that target and room', () => {
    const h = harness();
    const publicState = { version: '2.2.3', darkMagic: { state: { spells: [{ name: 'Fixture', effects: effect, castedBy: { id: 100 } }] } } };
    const packet = id => bcc(id, 'syncStorage', { storage: publicState });
    assert(!accepted(h, 'ChatRoomMessage', packet(300)));
    let sent = 0;
    h.W.ServerSend = () => { sent++; };
    h.W.bcModSdk = { apiVersion: 1, registerMod: () => ({ hookFunction: (name, _priority, hook) => {
        const old = h.W[name]; h.W[name] = (...args) => hook(args, next => old(...next));
    } }) };
    h.shield.tick();
    h.W.Player.AllowedInteractions = 5;
    const outgoing = { Content: 'BCC', Type: 'Hidden', Target: 300, Dictionary: { msg: 'castSpell', data: spell(effect) } };
    h.W.ServerSend('ChatRoomChat', outgoing);
    assert.equal(sent, 1); assert(accepted(h, 'ChatRoomMessage', packet(300)));
    assert(!accepted(h, 'ChatRoomMessage', packet(200)));
    h.W.Player.GhostList = [300]; assert(!accepted(h, 'ChatRoomMessage', packet(300)));
    h.W.Player.GhostList = []; h.W.ChatRoomData.ID = 'another-room';
    assert(!accepted(h, 'ChatRoomMessage', packet(300)));
});

test('Malformed addon metadata containers are rejected before addon property writes and array methods', () => {
    const h = harness();
    for (const darkMagic of [{ state: { spells: {} } }, { state: { spells: [null] } }, { state: { spells: [{ name: 'bad', effects: [], castedBy: null }] } }])
        assert(!accepted(h, 'ChatRoomMessage', bcc(200, 'syncStorage', { storage: { version: '2.2.3', darkMagic } })));
    for (const settings of [{ InjectorModule: 'bad' }, { MagicModule: [] }, { enabled: {} }])
        assert(!accepted(h, 'ChatRoomMessage', chat({ Sender: 200, Content: 'LSCGMsg', Type: 'Hidden', Dictionary: [{ message: { type: 'sync', settings } }] })));
});
