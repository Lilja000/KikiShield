'use strict';
// Real browser origin rules + exact R132 mask functions and ModSDK. Only local HTTP fixtures.
const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict'), http = require('node:http');
const { chromium } = process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES
    ? require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES + '/playwright') : require('playwright');
const root = process.env.KIKISHIELD_UPSTREAM || path.resolve(__dirname, '../..');
const read = f => fs.readFileSync(path.join(root, f), 'utf8');
const extract = (s,n) => { const i=s.indexOf(`function ${n}(`); assert(i>=0); return s.slice(i,s.indexOf('\n}',i)+2); };
const sdk = read('render-audit/bcmodsdk-R132.js');
const draw = read('render-audit/GLDraw-R132.js');
const native = ['GLDrawLoadTextureAlphaMask','GLDrawCreateEmptyTextureAlphaMask','GLDrawLoadImage','GLDrawBingImageToTextureInfo'].map(n=>extract(draw,n)).join('\n');
const feather = read('shield-hardening-audit/BC-Feather.user.js');
const patches = JSON.parse(feather.slice(feather.indexOf('[', feather.indexOf('const PATCHES =')), feather.indexOf('\n];', feather.indexOf('const PATCHES ='))+2));
const maskPatch = patches.find(p=>p.name==='GLDrawLoadTextureAlphaMask').replacements;
function mappingHook(source) {
    const start = source.indexOf('.hookFunction("GLDrawLoadTextureAlphaMask",'); assert(start>=0);
    let i = source.indexOf('(', start), depth=0, quote=null;
    for (; i<source.length; i++) {
        const c=source[i];
        if (quote) { if(c==='\\') i++; else if(c===quote) quote=null; }
        else if (c==='"'||c==="'"||c==='`') quote=c;
        else if (c==='(') depth++;
        else if (c===')'&&!--depth) { i++; break; }
    }
    const call='u'+source.slice(start,i), map=call.match(/Url:\s*(\w+)\.mapImgSrc/); assert(map,call);
    return `{const ${map[1]}={mapImgSrc:fixtureResolve};${call};}`;
}
const echoA = mappingHook(read('render-audit/echo-activity.js'));
const echoC = mappingHook(read('render-audit/echo-clothing.js'));
const bcc = mappingHook(read('bcc-2.2.1-archive/BCC-2.2.1-archived.user.js'));
const shield = fs.readFileSync(path.join(__dirname,'../KikiShield.user.js'),'utf8');
const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+a8WQAAAAASUVORK5CYII=','base64');

(async()=>{
 const browser=await chromium.launch({headless:true,...(process.env.KIKISHIELD_CHROMIUM?{executablePath:process.env.KIKISHIELD_CHROMIUM}:{}),args:['--no-sandbox','--use-angle=swiftshader','--enable-webgl']});
 const checks=[], errors=[], requests=[];
 const servers=[http.createServer((_req,res)=>{res.setHeader('Content-Type','text/html');res.end('<!doctype html><html><body><p>Offline R132 render fixture</p></body></html>');}),
  http.createServer((req,res)=>{requests.push({path:req.url,cors:req.headers.origin||null});res.setHeader('Content-Type','image/png');if(!req.url.includes('no-cors'))res.setHeader('Access-Control-Allow-Origin','*');res.end(png);})];
 await Promise.all(servers.map(s=>new Promise(resolve=>s.listen(0,'127.0.0.1',resolve))));
 const pageOrigin='http://127.0.0.1:'+servers[0].address().port, imagesOrigin='http://127.0.0.1:'+servers[1].address().port;
 try {
  const context=await browser.newContext();
  await context.route('**/*', route=>{
    if(route.request().url().startsWith(pageOrigin+'/')||route.request().url().startsWith(imagesOrigin+'/'))return route.continue();
    throw new Error('Unexpected external request '+route.request().url());
  });
  const page=await context.newPage(); page.on('pageerror',e=>errors.push(e.message));
  await page.goto(pageOrigin+'/');
  await page.addScriptTag({content:`var imagesOrigin=${JSON.stringify(imagesOrigin)}; var GLDrawImageCache=new Map();var refreshed=0;function DrawRefreshCharacterForImage(){refreshed++};\n${native}\n${sdk}\nvar fixtureResolve=url=>url==='virtual.png'?imagesOrigin+'/mapped.png':url; var featherTouches=0;window.BCFeather={_touchMask:()=>featherTouches++};`});
  await page.evaluate(()=>{
    window.gl=document.createElement('canvas').getContext('webgl2'); if(!gl) throw Error('WebGL2 unavailable'); gl.maskCache=new Map();gl.textureCache=new Map();
    window.loadFixtureImage=async(url,cors)=>{const img=new Image();if(cors)img.crossOrigin='anonymous';await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=reject;img.src=url;});GLDrawImageCache.set(url,img);return img;};
    window.mask=url=>GLDrawLoadTextureAlphaMask(gl,64,64,0,0,[{Url:url,X:0,Y:0}]);
  });
  await page.evaluate(async()=>{await loadFixtureImage(imagesOrigin+'/mapped.png',false);});
  assert.equal(await page.evaluate(()=>{try{mask(imagesOrigin+'/mapped.png');return 'none';}catch(e){return e.name;}}),'SecurityError');
  checks.push('Unprotected exact R132 loader reproduces SecurityError with a real cross-origin image');
  await page.addScriptTag({content:`{const u=bcModSdk.registerMod({name:'服装拓展',fullName:'Echo clothing fixture',version:'1'});${echoC}}\n{const u=bcModSdk.registerMod({name:'BCC',fullName:'BCC fixture',version:'2.2.1'});${bcc}}\n{const u=bcModSdk.registerMod({name:'动作拓展',fullName:'Echo activity fixture',version:'1'});${echoA}}\n{const u=bcModSdk.registerMod({name:'BCFeather',fullName:'BC Feather fixture',version:'2.0.0'});u.patchFunction('GLDrawLoadTextureAlphaMask',${JSON.stringify(maskPatch)});}`});
  await page.addScriptTag({content:shield});
  assert.equal(await page.evaluate(()=>KikiShield.status().graphics.state),'ready');
  assert.equal(await page.evaluate(()=>!!mask('virtual.png')),true);
  await page.waitForFunction(()=>KikiShield.status().graphics.recovered===1);
  assert.equal(await page.evaluate(()=>{const image=GLDrawImageCache.get(imagesOrigin+'/mapped.png');const c=document.createElement('canvas'),x=c.getContext('2d');x.drawImage(image,0,0);x.getImageData(0,0,1,1);return image.crossOrigin;}),'anonymous');
  assert.equal(await page.evaluate(()=>!!mask('virtual.png')),true);
  assert(await page.evaluate(()=>featherTouches>0&&refreshed===1));
  checks.push('BCC and both deployed Echo URL-mapping hooks remain in the real SDK chain');
  checks.push('BC Feather exact alpha-mask patch remains active');
  checks.push('Tainted cached image reloaded once with CORS, then draws successfully');
  checks.push('Native character image invalidation requested without player/network updates');
  const mapped=requests.filter(r=>r.path==='/mapped.png'); assert.equal(mapped.length,2); assert.equal(mapped[1].cors,pageOrigin);
  checks.push('Exactly one anonymous retry, to the already requested image URL');

  await page.evaluate(async()=>{await loadFixtureImage(imagesOrigin+'/no-cors.png',false);for(let i=0;i<100;i++)mask(imagesOrigin+'/no-cors.png');});
  await page.waitForFunction(()=>KikiShield.status().graphics.pending===0);
  await page.evaluate(()=>{for(let i=0;i<100;i++)mask(imagesOrigin+'/no-cors.png');});
  assert.equal(requests.filter(r=>r.path==='/no-cors.png').length,2);
  assert(await page.evaluate(()=>KikiShield.getLog().some(r=>r.reason==='imageFailed')), JSON.stringify(await page.evaluate(()=>({s:KikiShield.status(),log:KikiShield.getLog()}))));
  assert(await page.evaluate(()=>KikiShield.getLog().length<10));
  checks.push('No-CORS host falls back without recurring requests or unhandled exceptions');
  checks.push('Repeated unsafe masks do not flood the log');

  const counts=await page.evaluate(async()=>{
    const good=await loadFixtureImage(imagesOrigin+'/clean.png',true);
    const one=mask(good.src),two=mask(good.src);if(one!==two)throw Error('cache mismatch');
    const mixed=GLDrawLoadTextureAlphaMask(gl,64,64,0,0,[{Url:good.src,X:0,Y:0},{Url:imagesOrigin+'/no-cors.png',X:0,Y:0}]);
    const cleanOnly=GLDrawLoadTextureAlphaMask(gl,64,64,0,0,[{Url:good.src,X:0,Y:0}]);
    return {same:mixed===cleanOnly,recovered:KikiShield.status().graphics.recovered};
  }); assert.equal(counts.same,true); assert.equal(counts.recovered,1);
  checks.push('Healthy image cache hits do not trigger retries');
  checks.push('Healthy mask layers are retained when a second layer is unsafe');
  await page.evaluate(()=>{
    const bad=GLDrawImageCache.get(imagesOrigin+'/no-cors.png');
    const canvas=document.createElement('canvas');canvas.width=8;canvas.height=8;canvas.getContext('2d').drawImage(bad,0,0);
    GLDrawImageCache.set('canvas-mask',canvas);mask('canvas-mask');
    canvas.width=8;canvas.getContext('2d').fillRect(0,0,8,8);mask('canvas-mask');
  }); checks.push('Tainted canvas sources fall back and are rechecked after they change');
  await page.addScriptTag({content:`{const u=bcModSdk.registerMod({name:'UnrelatedError',fullName:'Fixture',version:'1'});window.removeFixtureHook=u.hookFunction('GLDrawLoadTextureAlphaMask',-2000000,()=>{throw Error('Fixture renderer failure')});}`});
  assert.equal(await page.evaluate(()=>{try{mask(imagesOrigin+'/clean.png')}catch(e){return e.message}}),'Fixture renderer failure');
  await page.evaluate(()=>removeFixtureHook());
  checks.push('Unrelated renderer exceptions are not swallowed');
  assert(await page.evaluate(()=>bcModSdk.getModsInfo().some(x=>x.name==='KikiShield'&&x.version==='0.4.0')));
  checks.push('KikiShield appears in ModSDK diagnostic reports');
  await page.locator('#kikishield-root').locator('#badge').click();
  await page.locator('#kikishield-root').locator('#advanced > summary').click();
  await page.locator('#kikishield-root').locator('#graphics').uncheck();
  assert.equal(await page.evaluate(()=>{try{mask(imagesOrigin+'/no-cors.png');return 'none';}catch(e){return e.name;}}),'SecurityError');
  await page.locator('#kikishield-root').locator('#graphics').check();
  assert(await page.evaluate(()=>!!mask(imagesOrigin+'/no-cors.png')));
  checks.push('Turning recovery off restores the original behavior; turning it on restores protection');
  await page.addScriptTag({content:`{const u=bcModSdk.registerMod({name:'LateEcho',fullName:'Late mapper fixture',version:'1'});${echoA}}`});
  assert(await page.evaluate(()=>!!mask('virtual.png')));
  checks.push('An Echo mapper registered after KikiShield still works');
  assert.deepEqual(errors,[]);
  checks.push('Zero unhandled browser errors in the guarded render scenarios');
  const report={browser:browser.version(),checks,passed:checks.length,network:'Two loopback HTTP fixtures exercise real browser CORS; all external requests are blocked. No game server or players.'};
  fs.writeFileSync(path.join(__dirname,'render-results.json'),JSON.stringify(report,null,2)+'\n'); console.log(JSON.stringify(report,null,2));
 }finally{await browser.close();await Promise.all(servers.map(s=>new Promise(resolve=>s.close(resolve))));}
})().catch(e=>{console.error(e);process.exitCode=1});
