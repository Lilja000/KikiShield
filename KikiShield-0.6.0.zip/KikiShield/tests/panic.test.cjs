'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { harness, chat, item } = require('./harness.cjs');
const fresh = stored => harness(undefined, stored, false);
const accepts = (h, event, data) => h.shield.filter([event, data]) !== null;
const bcc = (id = 200, msg = 'syncStorage', data = { storage: { version: '2.2.3' } }) => chat({ Sender: id, Type: 'Hidden', Content: 'BCC', Dictionary: { msg, data } });
const lscg = (id = 200, type = 'command') => chat({ Sender: id, Type: 'Hidden', Content: 'LSCGMsg', Dictionary: [{ message: type === 'sync'
    ? { type, settings: { enabled: true }, reply: false }
    : { type, target: 100, command: { name: 'spell', args: [] } } }] });

for (const Type of ['Chat', 'Whisper', 'Emote', 'Action', 'Activity', 'Hidden', 'ServerMessage', 'Custom']) {
    test(`Panic drops ${Type} before every native and addon listener, including self echoes`, () => {
        const h = fresh(); let listeners = 0;
        h.socket.onAny(() => listeners++); h.socket.on('ChatRoomMessage', () => listeners++);
        h.shield.setPanic(true);
        for (const Sender of [100, 200, 300]) h.receive('ChatRoomMessage', chat({ Type, Sender }));
        assert.equal(listeners, 0); assert.equal(h.shield.status().panic.active, true);
        h.shield.setPanic(false);
        h.receive('ChatRoomMessage', chat({ Sender: 200, Type: 'Chat' }));
        assert.equal(listeners, 2); // Only the new message is delivered.
    });
}

test('Panic discards beeps, game actions, BCC, LSCG and KikiLink envelopes', () => {
    const h = fresh(); const received = []; h.socket.onAny((...args) => received.push(args));
    h.shield.setPanic(true);
    for (const MemberNumber of [100, 200, 300]) h.receive('AccountBeep', { MemberNumber, Message: 'Synthetic beep' });
    for (const Sender of [100, 200, 300]) h.receive('ChatRoomGameResponse', { Sender, Data: { GameProgress: 'Next' } });
    h.receive('ChatRoomMessage', bcc()); h.receive('ChatRoomMessage', lscg());
    h.receive('ChatRoomMessage', chat({ Sender: 200, Type: 'Hidden', Content: 'KIKILINK/1 {"t":"pq"}' }));
    h.receive('AccountBeep', { MemberNumber: 200, BeepType: 'KikiLink', Message: 'KIKILINK/1 {"t":"pq"}' });
    assert.equal(received.length, 0);
    h.shield.setPanic(false); assert.equal(received.length, 0);
});

test('Panic preserves connection, authoritative account metadata and room lifecycle events', () => {
    const h = fresh(); const received = []; h.socket.onAny((event, data) => received.push([event, data]));
    const events = ['connect', 'disconnect', 'ServerInfo', 'LoginResponse', 'ForceDisconnect', 'AccountOwnership', 'AccountLovership',
        'ChatRoomSyncMemberJoin', 'ChatRoomSyncMemberLeave', 'ChatRoomSyncRoomProperties', 'ChatRoomSearchResponse'];
    h.shield.setPanic(true);
    for (const event of events) h.receive(event, { fixture: event });
    assert.deepEqual(received.map(x => x[0]), events);
    assert.equal(h.shield.status().connected, true);
});

test('Panic denies owner, lover and whitelist edits while allowing own native appearance changes', () => {
    const h = fresh(); h.W.Player.Ownership = { MemberNumber: 200 }; h.W.Player.Lovership = [{ MemberNumber: 300 }];
    h.shield.setPanic(true);
    assert.equal(accepts(h, 'ChatRoomSyncItem', item(200)), false);
    assert.equal(accepts(h, 'ChatRoomSyncItem', item(300)), false);
    assert.equal(accepts(h, 'ChatRoomSyncItem', item(100)), true);
    assert.equal(accepts(h, 'ChatRoomSyncItem', item(200, 300)), true); // Other characters remain synchronized.
    h.shield.setPanic(false); assert.equal(accepts(h, 'ChatRoomSyncItem', item(200)), true);
});

for (const event of ['ChatRoomSyncSingle', 'ChatRoomSyncCharacter']) {
    test(`Panic sanitizes ${event} appearance and keeps authoritative relationship metadata`, () => {
        const h = fresh(); h.shield.setPanic(true);
        const packet = { SourceMemberNumber: 200, Character: { MemberNumber: 100, Appearance: [{ Name: 'Changed' }], ActivePose: ['Changed'],
            Ownership: { MemberNumber: 200 }, Lovership: [{ MemberNumber: 300 }] } };
        const result = h.shield.filter([event, packet]);
        assert(result); assert.deepEqual(result[1].Character.Appearance, h.W.Player.Appearance);
        assert.deepEqual(result[1].Character.ActivePose, h.W.Player.ActivePose);
        assert.deepEqual(result[1].Character.Ownership, packet.Character.Ownership);
        assert.deepEqual(result[1].Character.Lovership, packet.Character.Lovership);
        assert.deepEqual(packet.Character.Appearance, [{ Name: 'Changed' }]);
    });
}

test('Panic keeps room snapshot metadata and other characters while preserving own accepted appearance', () => {
    const h = fresh(); h.shield.setPanic(true);
    const other = { MemberNumber: 200, Appearance: [{ Name: 'Other' }] };
    const result = h.shield.filter(['ChatRoomSync', { Name: 'Room changed', Character: [{ MemberNumber: 100, Appearance: [{ Name: 'Changed' }] }, other] }]);
    assert(result); assert.equal(result[1].Name, 'Room changed'); assert.equal(result[1].Character[1], other);
    assert.deepEqual(result[1].Character[0].Appearance, h.W.Player.Appearance);
});

test('Panic toggles are idempotent, do not send or save settings, and survive a same-tab account transition', () => {
    const h = fresh(); let outgoing = 0; h.W.ServerSend = () => outgoing++;
    h.W.Player.AudioSettings = { Volume: .7, MusicVolume: .4, PlayItem: true, Notifications: true };
    const before = structuredClone(h.shield.status().options), audioBefore = structuredClone(h.W.Player.AudioSettings), storageBefore = [...h.stored];
    h.shield.setPanic(true); h.shield.setPanic(true); h.flush();
    assert.equal(outgoing, 0); assert.equal(h.writes.length, 0);
    assert.deepEqual(h.shield.status().options, before); assert.deepEqual([...h.stored], storageBefore);
    assert.deepEqual(h.W.Player.AudioSettings, audioBefore);
    h.W.Player.MemberNumber = 400; h.shield.tick(); assert.equal(h.shield.status().panic.active, true);
    h.shield.setPanic(false); h.shield.setPanic(false); h.flush();
    assert.equal(outgoing, 0); assert.equal(h.writes.length, 0); assert.deepEqual([...h.stored], storageBefore);
    assert.deepEqual(h.W.Player.AudioSettings, audioBefore); assert.deepEqual(h.shield.status().options, before);
});

test('Panic drops arrivals before disconnected socket buffering so Resume cannot replay them', () => {
    const h = fresh(); const received = []; h.socket.onAny(event => received.push(event));
    h.socket.connected = false; h.shield.setPanic(true);
    h.receive('ChatRoomMessage', chat({ Sender: 200 }));
    h.receive('AccountBeep', { MemberNumber: 200, Message: 'Synthetic' });
    h.receive('ChatRoomGameResponse', { Sender: 200, Data: { GameProgress: 'Next' } });
    h.receive('ServerInfo', { synthetic: true });
    h.shield.setPanic(false); h.socket.connected = true; h.socket.emitBuffered();
    assert.deepEqual(received, ['ServerInfo']);
});

function audioFixture(fail = false) {
    const h = fresh(); const hooks = new Map(), installs = new Map();
    for (const name of ['AudioPlayInstantSound', 'AudioDialogStart', 'AudioPlaySoundEffect', 'AudioShouldSilenceSound', 'NotificationRaise']) h.W[name] = () => {};
    h.W.bcModSdk = { apiVersion: 1, registerMod: () => ({ hookFunction(name, priority, fn) {
        installs.set(name, (installs.get(name) || 0) + 1);
        if (fail) throw new Error('Synthetic registration failure');
        hooks.set(name, { priority, fn });
    } }) };
    h.shield.tick(); return { ...h, hooks, installs };
}

test('Panic audio/notification hooks preserve return types, unchanged args and normal downstream errors', () => {
    const h = audioFixture(); const returns = { AudioPlayInstantSound: undefined, AudioDialogStart: undefined,
        AudioPlaySoundEffect: false, AudioShouldSilenceSound: true, NotificationRaise: undefined };
    const sentinel = {}; let calls = 0;
    for (const [name, expected] of Object.entries(returns)) {
        const { fn, priority } = h.hooks.get(name); const args = [{ synthetic: true }];
        assert(priority > 0); assert.equal(fn(args, a => { assert.equal(a, args); calls++; return sentinel; }), sentinel);
        h.shield.setPanic(true); const before = calls;
        assert.equal(fn(args, () => { calls++; }), expected); assert.equal(calls, before);
        h.shield.setPanic(false);
        const error = new Error(name); assert.throws(() => fn(args, () => { throw error; }), e => e === error);
    }
    assert.equal(h.shield.status().panic.nativeAudioGuard, true);
    h.shield.tick(); h.shield.tick(); assert([...h.installs.values()].every(x => x === 1));
});

test('Missing or failed optional audio hooks do not throw or retry registration every second', () => {
    const plain = fresh(); assert.doesNotThrow(() => { plain.shield.setPanic(true); plain.shield.tick(); plain.shield.setPanic(false); });
    assert.equal(plain.shield.status().panic.nativeAudioGuard, false);
    const h = audioFixture(true); h.shield.setPanic(true);
    for (let i = 0; i < 6; i++) assert.doesNotThrow(() => h.shield.tick());
    assert.equal(h.shield.status().panic.nativeAudioGuard, false); assert([...h.installs.values()].every(x => x === 1));
});

test('Detached native media are muted and restored without touching volume, source, time or playback', () => {
    const h = fresh(); let plays = 0, pauses = 0;
    h.W.AudioDialog = { muted: false, volume: .6, currentTime: 4, src: 'synthetic', play() { plays++; }, pause() { pauses++; } };
    h.W.AudioBackgroundMusic = { muted: true, volume: .2, currentTime: 90, src: 'synthetic-music', play() { plays++; }, pause() { pauses++; } };
    h.shield.setPanic(true); assert.equal(h.W.AudioDialog.muted, true); assert.equal(h.W.AudioBackgroundMusic.muted, true);
    assert.equal(h.shield.status().panic.mutedMedia, 2);
    h.shield.setPanic(true); h.shield.tick(); h.shield.setPanic(false);
    assert.equal(h.W.AudioDialog.muted, false); assert.equal(h.W.AudioBackgroundMusic.muted, true);
    assert.equal(h.W.AudioDialog.volume, .6); assert.equal(h.W.AudioDialog.currentTime, 4); assert.equal(h.W.AudioDialog.src, 'synthetic');
    assert.equal(h.W.AudioBackgroundMusic.volume, .2); assert.equal(h.W.AudioBackgroundMusic.currentTime, 90);
    assert.equal(plays, 0); assert.equal(pauses, 0); assert.equal(h.shield.status().panic.mutedMedia, 0);
});

test('Throwing media property accessors do not crash Panic or prevent muting other audio', () => {
    const h = fresh(); h.W.AudioDialog = Object.defineProperty({}, 'muted', { get() { throw new Error('Synthetic closed media getter'); } });
    h.W.AudioBackgroundMusic = { muted: false };
    assert.doesNotThrow(() => h.shield.setPanic(true)); assert.equal(h.W.AudioBackgroundMusic.muted, true);
    assert.doesNotThrow(() => h.shield.tick()); assert.doesNotThrow(() => h.shield.setPanic(false));
    assert.equal(h.W.AudioBackgroundMusic.muted, false);
    const g = fresh(); g.W.AudioDialog = Object.defineProperty({}, 'muted', { get() { return false; }, set() { throw new Error('Synthetic denied setter'); } });
    assert.doesNotThrow(() => g.shield.setPanic(true)); assert.doesNotThrow(() => g.shield.setPanic(false));
});

test('Addon selection defaults isolate BCC metadata and commands while keeping authorized LSCG usable', () => {
    const h = fresh(); assert.equal(h.shield.status().options.blockBCC, true); assert.equal(h.shield.status().options.blockLSCG, false);
    assert.equal(accepts(h, 'ChatRoomMessage', bcc()), false);
    assert.equal(accepts(h, 'ChatRoomMessage', bcc(200, 'castSpell', { spell: { name: 'Synthetic' } })), false);
    assert.equal(accepts(h, 'ChatRoomMessage', lscg()), true); assert.equal(accepts(h, 'ChatRoomMessage', lscg(300, 'sync')), true);
    h.shield.configure({ blockLSCG: true }); assert.equal(accepts(h, 'ChatRoomMessage', lscg()), false);
    assert.equal(accepts(h, 'ChatRoomMessage', lscg(300, 'sync')), false);
    assert.equal(accepts(h, 'AccountBeep', { MemberNumber: 200, BeepType: 'Leash', Message: { IsLSCG: true, ...lscg().Dictionary[0].message } }), false);
    assert.equal(accepts(h, 'ChatRoomMessage', chat({ Sender: 200, Content: 'ordinary' })), true);
});

test('Turning addon isolation off retains recipient permissions, lists and BCC effect role checks', () => {
    const h = fresh(); h.shield.configure({ blockBCC: false, blockLSCG: false });
    const effect = String.fromCharCode(1002); h.W.LZString = { decompressFromBase64: s => s };
    h.W.Player.ExtensionSettings = { BCC: JSON.stringify({ darkMagic: { limits: { effects: { [effect]: 0 } } } }) };
    const command = id => bcc(id, 'castSpell', { spell: { name: 'Synthetic', icon: 'BeamsAura', effects: effect, data: {}, createdBy: { id, name: 'Synthetic' } } });
    assert.equal(accepts(h, 'ChatRoomMessage', bcc()), true); assert.equal(accepts(h, 'ChatRoomMessage', command(200)), true);
    assert.equal(accepts(h, 'ChatRoomMessage', command(300)), false); assert.equal(accepts(h, 'ChatRoomMessage', lscg(300)), false);
    for (const field of ['GhostList', 'BlackList']) {
        h.W.Player[field] = [200]; assert.equal(accepts(h, 'ChatRoomMessage', bcc()), false);
        assert.equal(accepts(h, 'ChatRoomMessage', command(200)), false); assert.equal(accepts(h, 'ChatRoomMessage', lscg()), false); h.W.Player[field] = [];
    }
    h.W.Player.AllowedInteractions = 5; assert.equal(accepts(h, 'ChatRoomMessage', command(200)), false);
    assert.equal(accepts(h, 'ChatRoomMessage', lscg()), false);
});

test('Old addon isolation preferences migrate and explicit per-addon choices take precedence', () => {
    const stored = value => new Map([['KikiShield.v1.100', JSON.stringify(value)]]);
    let h = fresh(stored({ isolateAddons: true }));
    assert.equal(h.shield.status().options.blockBCC, true); assert.equal(h.shield.status().options.blockLSCG, true);
    h = fresh(stored({ isolateAddons: false })); assert.equal(h.shield.status().options.blockBCC, true); assert.equal(h.shield.status().options.blockLSCG, false);
    h = fresh(stored({ isolateAddons: true, blockBCC: false, blockLSCG: false }));
    assert.equal(h.shield.status().options.blockBCC, false); assert.equal(h.shield.status().options.blockLSCG, false);
    h.shield.configure({ blockBCC: true, blockLSCG: true });
    assert.deepEqual(JSON.parse(h.stored.get('KikiShield.v1.100')), h.shield.status().options);
});
