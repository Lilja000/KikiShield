'use strict';
// Requires the pinned source checkouts listed in README.txt. No game connection.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const cp = require('node:child_process');
const { stripTypeScriptTypes } = require('node:module');
const { harness, chat, item } = require('./harness.cjs');
const root = process.env.KIKISHIELD_UPSTREAM || path.resolve(__dirname, '../..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const git = (repo, ref, file) => cp.execFileSync('git', ['show', `${ref}:${file}`], { cwd: path.join(root, repo), encoding: 'utf8', maxBuffer: 20e6 });
const clean = s => stripTypeScriptTypes(s, { mode: 'transform' }).replace(/^import .*;\s*$/mg, '').replace(/\bexport /g, '');
const extract = (source, name) => { const start = source.indexOf(`function ${name}(`); assert(start >= 0); return source.slice(start, source.indexOf('\n}', start) + 2); };
const socketSource = git('bc-client', '5eb495c5ced4ee92d40385b7521e6ca63ace12e5', 'BondageClub/Scripts/lib/socket.io/socket.io.min.js');
const moduleBox = { exports: {} };
vm.runInNewContext(socketSource, { module: moduleBox, exports: moduleBox.exports, setTimeout, clearTimeout });
const io = moduleBox.exports;
function realSocket() {
    // autoConnect:false is mandatory: this harness must never open a network connection.
    const manager = new io.Manager('http://offline.invalid', { autoConnect: false });
    return manager.socket('/');
}

test('Actual BC-bundled Socket.IO: filter precedes onAny and ordinary event listeners', () => {
    const h = harness(realSocket); let any = 0, native = 0;
    h.socket.onAny(() => any++); h.socket.on('ChatRoomMessage', () => native++);
    h.receive('ChatRoomMessage', chat({ Content: 'BCC' })); assert.equal(any, 0); assert.equal(native, 0);
    h.receive('ChatRoomMessage', chat()); assert.equal(any, 1); assert.equal(native, 1);
});
test('Actual Socket.IO: frozen buffered events, ack callbacks and return path survive', () => {
    const h = harness(realSocket); let seen = 0, ackType;
    h.socket.on('ChatRoomMessage', (_d, ack) => { seen++; ackType = typeof ack; }); h.socket.connected = false;
    h.socket.onevent({ type: 2, id: 9, data: ['ChatRoomMessage', chat()] });
    h.receive('ChatRoomMessage', chat({ Content: 'BCC' })); h.socket.connected = true; h.socket.emitBuffered();
    assert.equal(seen, 1); assert.equal(ackType, 'function');
});

test('Actual BC server permission function agrees with KikiShield on ordinary permissions', () => {
    const env = { AccountValidData: () => {}, ChatRoomDominantValue: c => c.Reputation[0]?.Value || 0 };
    vm.createContext(env); vm.runInContext(extract(read('bc-server/app.js'), 'ChatRoomGetAllowItem'), env);
    for (let permission = 0; permission < 6; permission++) for (const relation of ['none', 'white', 'lover', 'owner']) for (const rep of [-100, 0, 100]) {
        const h = harness(realSocket), p = h.W.Player, source = h.W.ChatRoomCharacter[1];
        p.AllowedInteractions = permission; p.ItemPermission = permission; p.WhiteList = []; source.Reputation = [{ Type: 'Dominant', Value: rep }];
        if (relation === 'white') p.WhiteList = [300]; if (relation === 'lover') p.Lovership = [{ MemberNumber: 300 }]; if (relation === 'owner') p.Ownership = { MemberNumber: 300 };
        assert.equal(h.shield.filter(['ChatRoomSyncItem', item(300)]) !== null, env.ChatRoomGetAllowItem(source, p), `${permission}/${relation}/${rep}`);
    }
});

for (const ref of ['de23c28', '280c1f2', '831dff2', '5e70b2e', '3b85255']) test(`Real BCC Chaos Aura ${ref}: no reflection callback after ingress rejection`, () => {
    const h = harness(realSocket), hooks = [];
    const env = { Player: Object.assign(h.W.Player, { HasOnBlacklist: () => false, HasOnGhostlist: () => false }),
        modStorage: { chaosAura: { enabled: true, triggers: { magicCast: true }, whiteList: [] } }, HookPriority: {},
        hookFunction: (_name, _priority, callback) => hooks.push(callback), getPlayer: () => ({ MemberNumber: 200 }),
        findModByName: () => true, isLSCGSpellBeneficial: () => false, shouldSpellBounceBack: () => false,
        syncStorage: () => {}, getRandomNumber: () => 1, CharacterNickname: () => 'Synthetic', messagesManager: { sendAction: () => {} },
        ServerSend: () => { throw new Error('Unexpected outbound command'); } };
    vm.createContext(env);
    const source = clean(git('bcc-audit', ref, 'src/modules/chaosAura.ts'));
    vm.runInContext(source.slice(source.indexOf('hookFunction("ChatRoomMessage",'), source.lastIndexOf('\n}')).trim(), env);
    h.W.Player.WhiteList = []; h.W.Player.AllowedInteractions = 3;
    const message = chat({ Sender: 200, Content: 'LSCGMsg', Type: 'Hidden', Dictionary: [{ message: { type: 'command', target: 100, command: { name: 'spell', args: [{ name: 'spell', value: { Name: 'Synthetic' } }] } } }] });
    // Baseline establishes that the selected upstream hook really is reachable.
    hooks[0]([message], () => {}); assert.equal(env.modStorage.chaosAura.triggersCount, 1);
    env.modStorage.chaosAura.triggersCount = 0;
    h.socket.on('ChatRoomMessage', data => hooks[0]([data], () => {})); h.receive('ChatRoomMessage', message);
    assert.equal(env.modStorage.chaosAura.triggersCount, 0);
});

test('Real BCC current AnimaFurta plus zois messaging: a permitted non-caster is rejected; the active caster still works', async () => {
    const h = harness(realSocket), hooks = [];
    h.W.Player.WhiteList.push(300); // Both have normal BC access; only 200 cast the effect.
    const lz = {}; vm.createContext(lz); vm.runInContext(read('shield-hardening-audit/LZString.js'), lz);
    h.W.LZString = lz.LZString;
    h.W.Player.ExtensionSettings = { BCC: lz.LZString.compressToBase64(JSON.stringify({version:'2.2.3',darkMagic:{limits:{effects:{[String.fromCharCode(1000)]:2}},state:{spells:[{name:'Synthetic',effects:String.fromCharCode(1000),castedBy:{id:200}}]}}})) };
    class BaseEffect { trigger() {} hookFunction() {} remove() {} }
    const sender = { MemberNumber: 300, BCC: {}, IsPlayer: () => false };
    const env = { Player: h.W.Player, BaseEffect, Effect: { ANIMA_FURTA: 1 }, HookPriority: {}, Atom: {},
        AnimaFurtaMessageDto: class {}, getSpellEffect: () => ({ isActive: true }), CommonTime: () => 0,
        ChatRoomMapViewMovement: null, MOD_DATA: { key: 'BCC' },
        hookFunction: (_name, _priority, fn) => { hooks.push(fn); return () => {}; }, getPlayer: id => ({ ...sender, MemberNumber: id }),
        validateData: async () => ({ isValid: true }), logger: { warn: () => {} },
        ServerSend: () => { throw new Error('Unexpected outbound command'); } };
    vm.createContext(env);
    const map = JSON.parse(read('bcc-bundle-current.map'));
    const i = map.sources.findIndex(s => s.includes('zois-core') && s.endsWith('/messaging.js'));
    assert(i >= 0);
    vm.runInContext(map.sourcesContent[i].replace(/^import .*;\s*$/mg, '').replace(/export\s*\{[\s\S]*?\};/g, ''), env);
    vm.runInContext(clean(git('bcc-audit', '3b85255', 'src/spell-effects/animaFurtaEffect.ts')) + '\nglobalThis.effect = new AnimaFurtaEffect();', env);
    env.effect.trigger({ init: true, spellName: 'Synthetic', sourceCharacter: { MemberNumber: 200 } });
    const msg = chat({ Sender: 300, Content: 'BCC', Type: 'Hidden', Dictionary: { msg: 'animaFurtaCommand', data: { name: 'mapMove', pos: { x: 5, y: 6 } } } });
    for (const hook of hooks) await hook([msg], () => {});
    assert.equal(h.W.Player.MapData.Pos.X, 5); delete h.W.Player.MapData;
    const pending = [];
    h.socket.on('ChatRoomMessage', data => { for (const hook of hooks) pending.push(hook([data], () => {})); });
    h.receive('ChatRoomMessage', msg); await Promise.all(pending);
    assert.equal(h.W.Player.MapData, undefined);
    h.receive('ChatRoomMessage', { ...msg, Sender: 200 }); await Promise.all(pending);
    assert.equal(h.W.Player.MapData.Pos.X, 5);
});

test('Real LSCG core/magic: denied packet schedules nothing; allowed packet reaches the native addon handler', () => {
    const h = harness(realSocket);
    const env = { BaseModule: class {}, Player: h.W.Player, ChatRoomData: { BlockCategory: [] },
        CharacterNickname: () => 'Synthetic', SendAction: () => {}, scheduled: 0,
        getCharacter: () => ({ MemberNumber: 300, IsPlayer: () => false }), dispatchExtensionCommand: () => {}, emit: () => {} };
    env.setTimeout = () => env.scheduled++;
    vm.createContext(env);
    vm.runInContext(clean(read('lscg-audit/src/Modules/magic.ts')) + '\nglobalThis.magic = Object.create(MagicModule.prototype);', env);
    Object.defineProperty(env.magic, 'Enabled', { value: true }); Object.defineProperty(env.magic, 'settings', { value: { requireWhitelist: false } });
    env.getModule = () => env.magic;
    vm.runInContext(clean(read('lscg-audit/src/Modules/core.ts')) + '\nglobalThis.core = Object.create(CoreModule.prototype); core.CommandListeners = [];', env);
    const msg = chat({ Content: 'LSCGMsg', Type: 'Hidden', Dictionary: [{ message: { type: 'command', target: 100, command: { name: 'spell', args: [] } } }] });
    env.core.CheckForPublicPacket(msg); assert.equal(env.scheduled, 1); env.scheduled = 0;
    h.socket.on('ChatRoomMessage', data => env.core.CheckForPublicPacket(data)); h.receive('ChatRoomMessage', msg);
    assert.equal(env.scheduled, 0);
    h.receive('ChatRoomMessage', { ...msg, Sender: 200 }); assert.equal(env.scheduled, 1);
});

test('Real BC arousal handler: denied activity does not reach the mutation sink, authorized activity does', () => {
    const h = harness(realSocket); h.W.Player.ArousalSettings = { Active: 'Automatic' };
    let effects = 0;
    const env = { Player: h.W.Player, AsylumGGTSActivity: () => {}, ActivityEffect: () => effects++ };
    vm.createContext(env); const source = read('bc-client/BondageClub/Screens/Online/ChatRoom/ChatRoom.js');
    const start = source.indexOf('var ChatRoomMessageHandlers = [');
    vm.runInContext(source.slice(start, source.indexOf('\n];', start) + 3), env);
    const handler = env.ChatRoomMessageHandlers.find(x => x.Description === 'Arousal processing');
    h.socket.on('ChatRoomMessage', data => handler.Callback(data, { MemberNumber: data.Sender }, '', {
        ActivityName: 'Synthetic', FocusGroup: { Name: 'Test' }, TargetMemberNumber: 100, TargetCharacter: h.W.Player
    }));
    h.receive('ChatRoomMessage', chat({ Type: 'Activity', Dictionary: [{ TargetCharacter: 100 }] })); assert.equal(effects, 0);
    h.receive('ChatRoomMessage', chat({ Sender: 200, Type: 'Activity', Dictionary: [{ TargetCharacter: 100 }] })); assert.equal(effects, 1);
});
