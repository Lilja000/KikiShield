'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { harness, TestSocket, chat, item } = require('./harness.cjs');

for (const content of ['BCC', 'LSCGMsg']) for (const type of ['Hidden', 'Chat', 'Action', 'Activity']) {
    test(`${content} malformed frame is stopped before listeners even with Type ${type}`, () => {
        const h = harness(); let calls = 0;
        h.socket.onAny(() => calls++).on('ChatRoomMessage', () => calls++);
        h.receive('ChatRoomMessage', chat({ Sender: 200, Content: content, Type: type, Dictionary: { msg: 'castSpell' } }));
        assert.equal(calls, 0); assert.equal(h.shield.status().blocked, 1);
    });
}
test('Malformed BCC own echo is rejected', () => {
    const h = harness(); let calls = 0; h.socket.on('ChatRoomMessage', () => calls++);
    h.receive('ChatRoomMessage', chat({ Sender: 100, Content: 'BCC', Dictionary: { msg: 'syncStorage' } }));
    assert.equal(calls, 0);
});
for (const list of ['BlackList', 'GhostList']) test(`${list} overrides Everyone, ownership, lover and whitelist`, () => {
    const h = harness(); h.W.Player[list] = [200]; h.W.Player.AllowedInteractions = 0;
    h.W.Player.Ownership = { MemberNumber: 200 }; h.W.Player.Lovership = [{ MemberNumber: 200 }];
    for (const [event, data] of [['ChatRoomMessage', chat({ Sender: 200 })], ['ChatRoomSyncItem', item(200)], ['AccountBeep', { MemberNumber: 200, Message: 'ordinary' }]])
        assert.equal(h.shield.filter([event, data]), null);
});
test('The sender whitelisting the recipient never grants access', () => {
    const h = harness(); assert.equal(h.shield.filter(['ChatRoomSyncItem', item(300)]), null);
    h.W.Player.WhiteList.push(300); assert.notEqual(h.shield.filter(['ChatRoomSyncItem', item(300)]), null);
});
test('Permissions are rechecked on every packet after whitelist removal', () => {
    const h = harness(); let applied = 0; h.socket.on('ChatRoomSyncItem', () => applied++);
    h.receive('ChatRoomSyncItem', item(200)); h.W.Player.WhiteList = []; h.receive('ChatRoomSyncItem', item(200));
    assert.equal(applied, 1);
});
for (let permission = 0; permission <= 5; permission++) test(`Permission level ${permission}: owner, lover, whitelist, dominance`, () => {
    const h = harness(); const p = h.W.Player; p.AllowedInteractions = permission;
    const allowed = id => h.shield.filter(['ChatRoomSyncItem', item(id)]) !== null;
    assert.equal(allowed(200), permission <= 3);
    assert.equal(allowed(300), permission <= 2);
    p.Lovership = [{ MemberNumber: 300 }]; assert.equal(allowed(300), permission <= 4);
    p.Ownership = { MemberNumber: 300 }; assert.equal(allowed(300), true);
});
test('Dominance boundary matches native permission 2', () => {
    const h = harness(); h.W.Player.AllowedInteractions = 2;
    h.W.Player.Reputation[0].Value = 50;
    h.W.ChatRoomCharacter[1].Reputation = [{ Type: 'Dominant', Value: 24 }];
    assert.equal(h.shield.filter(['ChatRoomSyncItem', item()]), null);
    h.W.ChatRoomCharacter[1].Reputation[0].Value = 25;
    assert.notEqual(h.shield.filter(['ChatRoomSyncItem', item()]), null);
});
test('Legacy ItemPermission supported; unknown policy fails closed for remote changes', () => {
    const h = harness(); delete h.W.Player.AllowedInteractions; h.W.Player.ItemPermission = 3;
    assert.notEqual(h.shield.filter(['ChatRoomSyncItem', item(200)]), null);
    h.W.Player.ItemPermission = 99; assert.equal(h.shield.filter(['ChatRoomSyncItem', item(200)]), null);
    assert.notEqual(h.shield.status().state, 'active');
});
test('Ordinary chat and ordinary beeps from nonblocked people still work', () => {
    const h = harness(); assert.notEqual(h.shield.filter(['ChatRoomMessage', chat()]), null);
    assert.notEqual(h.shield.filter(['AccountBeep', { MemberNumber: 300, Message: 'hello' }]), null);
});
test('Malformed LSCG beeps and unrecognized BCC request protocols are blocked', () => {
    const h = harness(); let seen = 0; h.socket.on('AccountBeep', () => seen++);
    for (const Message of [{ IsLSCG: true, type: 'command' }, JSON.stringify({ type: 'BCC_request' }), JSON.stringify({ type: 'BCC_requestResponse' })])
        h.receive('AccountBeep', { MemberNumber: 200, BeepType: 'Leash', Message });
    assert.equal(seen, 0);
});
test('Old and new native target dictionary formats enforce outer sender authority', () => {
    const h = harness();
    for (const Dictionary of [[{ TargetCharacter: 100 }], [{ Tag: 'DestinationCharacterName', MemberNumber: 100 }], [{ SourceCharacter: 100 }]]) {
        assert.equal(h.shield.filter(['ChatRoomMessage', chat({ Type: 'Activity', Dictionary })]), null);
    }
    assert.notEqual(h.shield.filter(['ChatRoomMessage', chat({ Sender: 200, Type: 'Activity', Dictionary: [{ TargetCharacter: 100 }] })]), null);
    assert.notEqual(h.shield.filter(['ChatRoomMessage', chat({ Type: 'Activity', Dictionary: [{ TargetCharacter: 200 }] })]), null);
});
test('Malformed and oversized targeted packets never reach listeners', () => {
    const h = harness();
    for (const data of [null, [], { Sender: '200', Content: 'x', Type: 'Hidden' }, chat({ Type: 'Activity', Dictionary: {} }), chat({ Type: 'Activity', Dictionary: Array(257).fill({}) })])
        assert.equal(h.shield.filter(['ChatRoomMessage', data]), null);
    for (const Source of [null, undefined, -1, NaN, '200', Infinity]) assert.equal(h.shield.filter(['ChatRoomSyncItem', item(Source)]), null);
});
test('A missing account cannot authorize a command; login remains deliverable', () => {
    const h = harness(); h.W.Player = null;
    assert.equal(h.shield.filter(['ChatRoomMessage', chat({ Type: 'Hidden' })]), null);
    const args = ['LoginResponse', { arbitrary: true }]; assert.equal(h.shield.filter(args), args);
});
test('Updates to other people, self updates, and room lifecycle are preserved', () => {
    const h = harness(); h.W.Player.BlackList = [300];
    assert.notEqual(h.shield.filter(['ChatRoomSyncItem', item(300, 200)]), null);
    assert.notEqual(h.shield.filter(['ChatRoomSyncItem', item(100)]), null);
    for (const event of ['ChatRoomSyncMemberJoin', 'ChatRoomSyncMemberLeave', 'ChatRoomSyncRoomProperties', 'AccountOwnership', 'ForceDisconnect', 'disconnect']) {
        const args = [event, { SourceMemberNumber: 300 }]; assert.equal(h.shield.filter(args), args);
    }
});
for (const event of ['ChatRoomSyncSingle', 'ChatRoomSyncCharacter']) test(`${event}: refused appearance is sanitized while server relationships survive`, () => {
    const h = harness(); const data = { SourceMemberNumber: 300, Character: { MemberNumber: 100, Appearance: [{ Name: 'Bad' }], ActivePose: ['Bad'], Ownership: { MemberNumber: 500 } } };
    let seen; h.socket.on(event, x => { seen = x; }); h.receive(event, data);
    assert.deepEqual(seen.Character.Appearance, h.W.Player.Appearance);
    assert.deepEqual(seen.Character.ActivePose, ['Base']); assert.equal(seen.Character.Ownership.MemberNumber, 500);
    assert.equal(data.Character.Appearance[0].Name, 'Bad'); h.flush(); assert.equal(h.writes.length, 1);
});
test('Room snapshots cannot replay rejected appearance, even with source == self', () => {
    const h = harness();
    for (const source of [100, 200, 300]) {
        const other = { MemberNumber: 300, Appearance: [{ Name: 'Other' }] };
        const data = { SourceMemberNumber: source, Admin: [300], Character: [other, { MemberNumber: 100, Appearance: [{ Name: 'Bad' }], ActivePose: ['Bad'] }] };
        const result = h.shield.filter(['ChatRoomSync', data])[1];
        assert.equal(result.Character[0], other); assert.equal(result.Character[1].Appearance[0].Name, 'Accepted');
        assert.deepEqual(result.Admin, [300]); assert.equal(data.Character[1].Appearance[0].Name, 'Bad');
    }
});
test('Repair bursts are coalesced and capped; no copied remote appearance is sent', () => {
    const h = harness();
    for (let burst = 0; burst < 5; burst++) { for (let n = 0; n < 100; n++) h.receive('ChatRoomSyncItem', item()); h.flush(); }
    assert.equal(h.writes.length, 3); assert.equal(h.shield.status().repairLimited, true);
    assert(h.writes.every(p => p.MemberNumber === 100 && p.Appearance[0].Name === 'Accepted'));
});
test('Leaving a room or disabling repair cancels pending correction', () => {
    const h = harness(); h.receive('ChatRoomSyncItem', item()); h.W.ChatRoomData = null; h.flush(); assert.equal(h.writes.length, 0);
    h.W.ChatRoomData = { ID: 'offline' }; h.receive('ChatRoomSyncItem', item()); h.shield.configure({ restoreAppearance: false }); h.flush(); assert.equal(h.writes.length, 0);
});
test('Buffered messages are rechecked using current permissions at delivery', () => {
    const h = harness(); let seen = 0; h.socket.on('ChatRoomSyncItem', () => seen++); h.socket.connected = false;
    h.receive('ChatRoomSyncItem', item(200)); h.W.Player.WhiteList = []; h.socket.connected = true; h.socket.emitBuffered();
    assert.equal(seen, 0);
});
test('A replacement socket is protected immediately and reconnect does not duplicate hooks', () => {
    const h = harness(); const replacement = new TestSocket(); h.W.ServerSocket = replacement;
    const wrapper = replacement.emitEvent; h.shield.tick(); h.shield.tick(); assert.equal(replacement.emitEvent, wrapper);
    replacement.connected = true; let seen = 0; replacement.onAny(() => seen++);
    replacement.onevent({ data: ['ChatRoomMessage', chat({ Content: 'BCC' })] }); assert.equal(seen, 0);
});
test('Socket method replacement is detected and onevent still gates known bad packets', () => {
    const h = harness(); let seen = 0; h.socket.emitEvent = () => seen++;
    h.receive('ChatRoomMessage', chat({ Content: 'BCC' })); assert.equal(seen, 0);
    assert.equal(h.shield.status().state, 'degraded'); h.shield.tick(); assert.equal(h.shield.status().hooked, true);
});
test('Unsupported socket and late installation never show green', () => {
    const h = harness(() => ({ connected: true })); assert.equal(h.shield.status().state, 'degraded');
    const late = harness(() => { const s = new TestSocket(); s.connected = true; return s; }); assert.equal(late.shield.status().late, true);
});
test('Extra restrictions cannot disable protocol validation or blacklist filters', () => {
    const h = harness(); h.shield.configure({ interactionMode: 'none' });
    assert.equal(h.shield.filter(['ChatRoomSyncItem', item(200)]), null);
    h.shield.configure({ interactionMode: 'whitelist' }); h.W.Player.Ownership = { MemberNumber: 300 };
    assert.equal(h.shield.filter(['ChatRoomSyncItem', item(300)]), null);
    h.shield.configure({ blockOtherHidden: true });
    assert.equal(h.shield.filter(['ChatRoomMessage', chat({ Sender: 200, Type: 'Hidden', Content: 'OtherMod' })]), null);
    h.shield.configure({ blockBCC: false }); assert.equal(h.shield.filter(['ChatRoomMessage', chat({ Content: 'BCC' })]), null);
});
test('Preferences are per-account and corrupt storage fails to defaults', () => {
    const h = harness(); h.shield.configure({ interactionMode: 'none' });
    assert.equal(JSON.parse(h.stored.get('KikiShield.v1.100')).interactionMode, 'none');
    h.W.Player.MemberNumber = 400; h.stored.set('KikiShield.v1.400', '{broken'); h.shield.tick();
    assert.equal(h.shield.status().options.interactionMode, 'native');
});
test('Log memory is bounded and does not contain message content', () => {
    const h = harness();
    for (let i = 0; i < 500; i++) h.receive('ChatRoomMessage', chat({ Sender: i + 600, Content: 'BCC', Dictionary: { secret: 'DO_NOT_LOG' } }));
    assert.equal(h.shield.getLog().length, 100); assert.equal(h.shield.status().blocked, 500);
    assert(!JSON.stringify(h.shield.getLog()).includes('DO_NOT_LOG'));
});
